"""Informe vectorial de una instantánea óptima. No acepta datos editables actuales."""
from io import BytesIO
from pathlib import Path
from xml.sax.saxutils import escape
import reportlab
from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle,getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer,Table,TableStyle,PageBreak,KeepTogether
from reportlab.graphics.shapes import Drawing,Line,String,Rect
from escenarios import es_optimo
from exploracion import conclusiones,cambios_entrada
from presentacion import formato,fecha_legible,COLORES
from version_modelo import version_ejecucion

AZUL=colors.HexColor('#214E65');GRIS=colors.HexColor('#526777')

def texto(v):
    return escape(str(v).replace('–','-').replace('−','-').replace('→','a')).replace('\n','<br/>')


def grafico(h,series,unidad,dt=1,niveles=None):
    """Escalones de periodos completos; los niveles son puntos de final de periodo."""
    ancho,alto=480,190;d=Drawing(ancho,alto);izq,abajo,area_x,area_y=54,40,412,126
    valores=[float(v) for col in series for v in h[col]]
    if niveles:valores += [float(v) for v in niveles.values()]
    minimo=min(valores) if unidad=='m' else min(0,min(valores));maximo=max(valores)
    margen=max((maximo-minimo)*.08,.02 if unidad=='m' else 1)
    if unidad=='m':minimo-=margen
    maximo+=margen;span=maximo-minimo
    def x(t):return izq+float(t)/(24*dt)*area_x
    def y(v):return abajo+(float(v)-minimo)/span*area_y
    d.add(String(izq,alto-11,unidad,fontName='UI',fontSize=9,fillColor=GRIS))
    for k in range(4):
        v=minimo+span*k/3;yy=y(v)
        d.add(Line(izq,yy,izq+area_x,yy,strokeColor=colors.HexColor('#E0E7EC'),strokeWidth=.5))
        d.add(String(izq-6,yy-3,formato(v,2 if unidad=='m' else 0),fontName='UI',fontSize=7.5,textAnchor='end',fillColor=GRIS))
    for t in range(0,25,4):
        xx=x(t*dt);d.add(String(xx,abajo-13,str(t),fontName='UI',fontSize=8,textAnchor='middle',fillColor=GRIS))
    for j,(col,(nombre,color)) in enumerate(series.items()):
        puntos=[]
        if niveles:
            puntos=[(x(0),y(niveles[col]))]+[(x((int(f.hora)+1)*dt),y(f[col])) for _,f in h.iterrows()]
        else:
            for _,f in h.iterrows():puntos.extend([(x(f.hora*dt),y(f[col])),(x((f.hora+1)*dt),y(f[col]))])
        for (a,b),(c,e) in zip(puntos,puntos[1:]):d.add(Line(a,b,c,e,strokeColor=colors.HexColor(color),strokeWidth=1.5))
        lx=izq+(j%3)*140;ly=12-(j//3)*11
        d.add(Line(lx,ly+3,lx+12,ly+3,strokeColor=colors.HexColor(color),strokeWidth=2))
        d.add(String(lx+16,ly,nombre,fontName='UI',fontSize=7.5,fillColor=GRIS))
    return d


def crear_pdf(e,originales,dt):
    if not es_optimo({'parametros':e.get('parametros'),'ejecucion':e}):
        raise ValueError('El informe requiere una solución óptima válida de la versión actual.')
    if dt<=0:raise ValueError('Duración de periodo no válida.')
    fuentes=Path(reportlab.__file__).parent/'fonts'
    for nombre,archivo in [('UI','Vera.ttf'),('UI-Bold','VeraBd.ttf')]:
        if nombre not in pdfmetrics.getRegisteredFontNames():pdfmetrics.registerFont(TTFont(nombre,str(fuentes/archivo)))
    pdfmetrics.registerFontFamily('UI',normal='UI',bold='UI-Bold',italic='UI',boldItalic='UI-Bold')
    estilos=getSampleStyleSheet()
    normal=ParagraphStyle('Cuerpo',fontName='UI',fontSize=9,leading=14,textColor=GRIS,spaceAfter=8)
    titulo=ParagraphStyle('Titulo',parent=normal,fontName='UI-Bold',fontSize=23,leading=28,textColor=AZUL,spaceAfter=14)
    seccion=ParagraphStyle('Seccion',parent=normal,fontName='UI-Bold',fontSize=14,leading=19,textColor=AZUL,spaceAfter=12)
    pequeno=ParagraphStyle('Pequeno',parent=normal,fontSize=7.5,leading=11)
    def p(t,estilo=normal):return Paragraph(texto(t),estilo)
    def tabla(filas,anchos):
        t=Table([[p(c,pequeno) for c in fila] for fila in filas],colWidths=anchos,repeatRows=1,hAlign='LEFT')
        t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#E7F0F3')),('LINEBELOW',(0,0),(-1,0),.7,AZUL),('LINEBELOW',(0,1),(-1,-1),.3,colors.HexColor('#DDE5EA')),('VALIGN',(0,0),(-1,-1),'TOP'),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]));return t
    r=e['resultados'];h=r['horas'].sort_values('hora');c=conclusiones(e,dt)
    cambios=cambios_entrada(e['parametros'],originales,e.get('escenario','Escenario'))
    destino=BytesIO();doc=SimpleDocTemplate(destino,pagesize=A4,rightMargin=42,leftMargin=42,topMargin=52,bottomMargin=42,title='Red eléctrica - '+e.get('escenario','Escenario'),author='MCOI')
    def pie(canvas,documento):
        canvas.setStrokeColor(colors.HexColor('#DDE5EA'));canvas.line(42,30,A4[0]-42,30)
        canvas.setFont('UI',7);canvas.setFillColor(GRIS);canvas.drawString(42,19,'MCOI | Red eléctrica | '+version_ejecucion(e));canvas.drawRightString(A4[0]-42,19,str(documento.page))
    relato=[p('RED ELÉCTRICA · INFORME DE ESCENARIO',pequeno),p(e.get('escenario','Escenario'),titulo),p(e.get('descripcion_escenario','') or 'Sin descripción.'),
            p('Resolución óptima | '+fecha_legible(e['fecha'])+' | '+version_ejecucion(e)),
            p('Instantánea de la resolución: los indicadores, gráficos y parámetros de este informe pertenecen a la misma ejecución. Las ediciones pendientes en la aplicación no se incluyen.',pequeno),
            p('Coste neto total: '+formato(r['coste_total'])+' €',seccion),
            tabla([['Indicador','Valor','Interpretación'],
                   ['Demanda atendida',formato(h.demanda.sum()*dt,1)+' MWh','Suma de potencia por duración de periodo.'],
                   ['Generación bruta',formato(h.generacion.sum()*dt,1)+' MWh','Producción acumulada de A, B, C, D, E y F.'],
                   ['Compra / venta',formato(c['compra_MWh'],1)+' / '+formato(c['venta_MWh'],1)+' MWh','Intercambios exteriores acumulados.'],
                   ['Bombeo',formato(c['bombeo_MWh'],1)+' MWh','Electricidad consumida para elevar agua.'],
                   ['Menor margen de reserva',formato(c['margen_minimo'])+' MW','Reserva disponible menos requerida.']], [135,145,231]),Spacer(1,18),p('Hechos destacados',seccion)]
    periodos=lambda horas:', '.join(f'{x:02d}:00-{x+1:02d}:00' for x in horas)
    relato += [p('Máxima demanda: '+formato(c['demanda_maxima'])+' MW. Periodos: '+periodos(c['horas_maxima_demanda'])+'.'),
               p('Menor margen de reserva: '+formato(c['margen_minimo'])+' MW. Periodos: '+periodos(c['horas_menor_reserva'])+'.'),
               p('Líneas a su capacidad: '+str(len(c['lineas_saturadas']))+'. El detalle de todos los periodos se incluye al final. Tolerancia: 0,000001 MW; se excluyen capacidad cero y flujos no apreciables.'),
               p('Balance: generación + compras = demanda + ventas + bombeo. El menor margen no es generación ya suministrada, sino capacidad disponible sobre la reserva exigida.',pequeno),
               PageBreak(),p('Producción y atención de la demanda',titulo),
               p('Producción por central',seccion),grafico(h,{x:(x,COLORES[x]) for x in 'ABCDEF'},'MW',dt),Spacer(1,20),
               p('Balance del sistema',seccion),grafico(h,{'demanda':('Demanda','#162B42'),'generacion':('Generación bruta','#24748D'),'aporte_neto':('Aporte neto','#B16625')},'MW',dt),
               p('Aporte neto = generación bruta + compras - ventas - bombeo. Demanda y aporte neto pueden superponerse. Las potencias se representan por periodos completos de '+formato(dt)+' h, con horas 0 a 23.',pequeno),
               PageBreak(),p('Mercado y embalses',titulo),
               p('Intercambios exteriores',seccion),grafico(h,{'compra':('Compra','#24748D'),'venta':('Venta','#B16625')},'MW',dt),Spacer(1,20),
               p('Nivel del depósito superior',seccion),grafico(h,{'nivel_B':('Embalse B','#276B48'),'nivel_E':('Embalse E','#4C9184')},'m',dt,{'nivel_B':e['parametros']['NIH']['B'],'nivel_E':e['parametros']['NIH']['E']}),
               p('El punto inicial representa NIH; los demás puntos representan el nivel al final del periodo. Escala adaptada a los niveles observados. Límites del escenario: '+formato(e['parametros']['LIH'],3)+' a '+formato(e['parametros']['LSH'],3)+' m. No se exige recuperar el nivel inicial.',pequeno),
               PageBreak(),p('Configuración y comprobaciones',titulo),p('Parámetros modificados respecto al caso original',seccion)]
    if cambios.empty:relato.append(p('Los parámetros utilizados coinciden con el caso original de esta versión.'))
    else:
        filas=[['Parámetro','Índice','Original','Utilizado','Unidad']]+[[f['Parámetro'],f['Índice'],formato(f['Referencia'],6),formato(f['Escenario comparado'],6),f['Unidad']] for f in cambios.to_dict('records')]
        relato.append(tabla(filas,[165,45,100,100,101]))
        relato.append(p('Los valores se muestran con seis decimales en este informe; el cálculo, la comparación exacta y los archivos CSV/JSON conservan su precisión original.',pequeno))
    relato += [Spacer(1,16),p('Líneas que alcanzan su capacidad',seccion)]
    if c['lineas_saturadas']:
        relato.append(tabla([['Línea','Periodos de la solución']]+[[l,periodos(horas)] for l,horas in c['lineas_saturadas'].items()],[60,451]))
    else:relato.append(p('Ninguna línea alcanza su capacidad con flujo apreciable.'))
    v=r['verificacion'];relato += [Spacer(1,16),p('Comprobación numérica',seccion),p('Validación de la solución: '+('correcta' if v.get('valida') else 'revisar diagnóstico')+'. Residuo máximo de restricciones: '+f"{v.get('max_residuo_restricciones',0):.6g}"+'; violación máxima de cotas: '+f"{v.get('max_violacion_cotas',0):.6g}"+'.',pequeno),p('Identificación de la instantánea: '+e.get('huella','')+' | SHA del modelo: '+e.get('sha_modelo',''),pequeno),p('Las observaciones describen esta solución. No atribuyen causas a las decisiones económicas ni demuestran causalidad cuando se modifican varios parámetros.',pequeno)]
    doc.build(relato,onFirstPage=pie,onLaterPages=pie)
    return destino.getvalue()
