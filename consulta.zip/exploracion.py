"""Lectura de instantáneas y navegación; nunca construye ni resuelve el modelo."""
from copy import deepcopy
import math
import pandas as pd
import streamlit as st
from escenarios import cambios_parametros,es_optimo
from red_horaria import intervalo


def cambios_entrada(datos,originales,nombre='Configuración editable'):
    return cambios_parametros({'parametros':originales},[{'nombre':nombre,'parametros':datos}])


def conclusiones(e,duracion):
    if not es_optimo({'parametros':e.get('parametros'),'ejecucion':e}):
        raise ValueError('Se necesita una instantánea óptima de la versión actual.')
    r=e['resultados'];h=r['horas'];pico=float(h.demanda.max());margen=float(h.margen_reserva.min())
    u=r['tablas']['utilizacion_lineas']
    llenas=u[(u['Capacidad (MW)']>0)&(u['Flujo (MW)'].abs()>1e-6)&((u['Capacidad (MW)']-u['Flujo (MW)'].abs())<=1e-6)]
    return {'demanda_maxima':pico,'horas_maxima_demanda':[int(x) for x in h.loc[(h.demanda-pico).abs()<=1e-6,'hora']],
            'margen_minimo':margen,'horas_menor_reserva':[int(x) for x in h.loc[(h.margen_reserva-margen).abs()<=1e-6,'hora']],
            'lineas_saturadas':{str(l):sorted(int(x) for x in g.Hora) for l,g in llenas.groupby('Línea')},
            'compra_MWh':float(h.compra.sum())*duracion,'venta_MWh':float(h.venta.sum())*duracion,
            'bombeo_MWh':float(h.bombeo.sum())*duracion,'duracion_h':duracion}


def abrir_red(hora,elemento=None):
    if isinstance(hora,bool) or int(hora)!=hora or not 0<=hora<=23:raise ValueError('Hora no válida.')
    st.session_state['hora_red']=int(hora)
    st.session_state['apartado']='Reserva y red'
    if elemento:st.session_state['elemento_red']=elemento


def desde_grafico(clave):
    evento=st.session_state.get(clave,{})
    seleccion=evento.get('selection',{}).get('hora',[])
    if seleccion:
        hora=seleccion[-1].get('hora')
        if not isinstance(hora,bool) and isinstance(hora,(int,float)) and math.isfinite(hora) and int(hora)==hora and 0<=hora<=23:
            abrir_red(int(hora))


def restaurar_bloque(parametros,originales):
    actual=deepcopy(st.session_state['datos_actuales'])
    for p in parametros:actual[p]=deepcopy(originales[p])
    for k in list(st.session_state):
        if k.startswith(('e_','s_')):del st.session_state[k]
    st.session_state['revision_edicion']=st.session_state.get('revision_edicion',0)+1
    st.session_state['base_edicion']=deepcopy(actual)
    st.session_state['datos_actuales']=actual
    # La ejecución y su identidad se conservan; la comparación exacta decide vigencia.


def mostrar_conclusiones(e,duracion):
    from presentacion import tarjetas,formato,tabla
    c=conclusiones(e,duracion)
    st.markdown('#### Qué destaca en esta solución')
    total=len(c['horas_maxima_demanda'])
    tarjetas([('Máxima demanda',formato(c['demanda_maxima'],2),'MW',f"Se alcanza en {total} "+('periodo.' if total==1 else 'periodos.')),
              ('Líneas a su capacidad',str(len(c['lineas_saturadas'])),'líneas','El detalle inferior recoge todos los periodos afectados.')],compactas=True)
    a,b=st.columns(2)
    for columna,opciones,etiqueta,clave in [(a,c['horas_maxima_demanda'],'Periodo de máxima demanda','pico'),(b,c['horas_menor_reserva'],'Periodo de menor reserva','reserva')]:
        with columna:
            if st.session_state.get('conclusion_'+clave) not in opciones:st.session_state['conclusion_'+clave]=opciones[0]
            hora=st.selectbox(etiqueta,opciones,format_func=intervalo,key='conclusion_'+clave)
            st.button('Abrir en la red',key='ir_'+clave,on_click=abrir_red,args=(hora,),width='stretch')
    st.write(f"Intercambios diarios: **{formato(c['compra_MWh'],1)} MWh comprados** y **{formato(c['venta_MWh'],1)} MWh vendidos**. Bombeo: {formato(c['bombeo_MWh'],1)} MWh consumidos.")
    st.caption('Se incluyen todos los empates de demanda máxima y margen mínimo dentro de una tolerancia de 0,000001 MW.')
    with st.expander(f"Líneas que alcanzan su capacidad · {len(c['lineas_saturadas'])}"):
        if not c['lineas_saturadas']:st.write('Ninguna línea transporta un flujo apreciable a su capacidad, con tolerancia de 0,000001 MW.')
        else:
            tabla('lineas_al_limite',pd.DataFrame([{'Línea':l,'Periodos':', '.join(f'{x:02d}:00–{x+1:02d}:00' for x in horas)} for l,horas in c['lineas_saturadas'].items()]))
            lineas=list(c['lineas_saturadas'])
            if st.session_state.get('conclusion_linea') not in lineas:st.session_state['conclusion_linea']=lineas[0]
            linea=st.selectbox('Línea para explorar',lineas,key='conclusion_linea')
            opciones=c['lineas_saturadas'][linea]
            if st.session_state.get('conclusion_hora_linea') not in opciones:st.session_state['conclusion_hora_linea']=opciones[0]
            hora=st.selectbox('Periodo al límite',opciones,format_func=intervalo,key='conclusion_hora_linea')
            st.button('Ver línea en la red',on_click=abrir_red,args=(hora,'linea:'+linea),key='ir_linea')
        st.caption('Capacidad nominal en el sentido permitido por el modelo; se excluyen capacidad cero y flujos no apreciables. Estas observaciones describen la solución, sin atribuir causas económicas.')
