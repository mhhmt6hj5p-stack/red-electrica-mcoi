from version_modelo import ejecucion_vigente
"""Metadatos y validación. Los valores originales se leen exclusivamente de App.py."""
from copy import deepcopy
import hashlib
import json
import math
import pandas as pd
from pyomo.environ import Param, value

# nombre: etiqueta, unidad, explicación, mínimo, máximo, factor de presentación
META = {
    'DM': ('Demanda máxima', 'MW', 'Demanda máxima prevista en cada centro.', 0, None, 1),
    'd': ('Demanda horaria', '%', 'Porcentaje de la demanda máxima, común a los cinco centros.', 0, 100, 100),
    'NMAXT': ('Potencia máxima', 'MW', 'Capacidad de generación térmica.', 0, None, 1),
    'nminT': ('Mínimo técnico', '%', 'Porcentaje de la potencia máxima cuando está encendida.', 0, 100, 100),
    'CMINT': ('Coste mínimo', '€/h', 'Coste por estar encendida al mínimo técnico.', 0, None, 1),
    'CEXTT': ('Coste extra', '€/MW por hora', 'Coste adicional por MW sobre el mínimo en un periodo de una hora.', 0, None, 1),
    'CPMT': ('Coste de arranque', '€', 'Coste por arranque térmico.', 0, None, 1),
    'NGH': ('Potencia de generación', 'MW', 'Producción fija al generar.', 0, None, 1),
    'CHH': ('Coste horario', '€/h', 'Coste de funcionamiento hidráulico.', 0, None, 1),
    'CPMH': ('Coste de arranque', '€', 'Coste por arranque hidráulico.', 0, None, 1),
    'RNAH': ('Reducción de nivel', 'm/h', 'Descenso del agua durante una hora de generación.', 0, None, 1),
    'NIH': ('Nivel inicial', 'm', 'Nivel antes de comenzar la hora 0.', 0, None, 1),
    'LIH': ('Nivel mínimo', 'm', 'Límite inferior en la operación programada de ambos embalses.', 0, None, 1),
    'LSH': ('Nivel máximo', 'm', 'Límite superior de ambos embalses.', 0, None, 1),
    'ES': ('Energía para elevar un metro', 'MWh/m', 'Energía de bombeo por metro de aumento del nivel.', 0.000001, None, 1),
    'MB': ('Límite de bombeo', 'MW', 'Big-M común aplicado a cada central: PB[h,i] ≤ MB × alphaBH[h,i]. No es un límite conjunto.', 0, None, 1),
    'NMAXN': ('Potencia máxima', 'MW', 'Capacidad máxima de la central nuclear.', 0, None, 1),
    'nminN': ('Mínimo técnico', '%', 'Porcentaje de la potencia máxima nuclear.', 0, 100, 100),
    'CMINN': ('Coste mínimo', '€/h', 'Coste nuclear al mínimo técnico.', 0, None, 1),
    'CPMN': ('Coste de arranque', '€', 'Coste por arranque nuclear.', 0, None, 1),
    'PEX': ('Potencia extra', 'MW', 'Abscisa de cada punto de interpolación, por encima del mínimo nuclear.', 0, None, 1),
    'PREC': ('Precio de potencia extra', '€/MW por hora', 'Se multiplica por PEX para calcular el coste CEX de cada punto.', 0, None, 1),
    'PC': ('Precio de compra', '€/MWh', 'Precio horario de la energía comprada al exterior. Puede ser negativo.', None, None, 1),
    'PV': ('Precio de venta', '€/MWh', 'Precio horario de la energía vendida al exterior. Puede ser negativo.', None, None, 1),
    'CAP': ('Capacidad', 'MW', 'Límite de flujo en cada sentido. Cero permite simular un corte.', 0, None, 1),
    'PR': ('Reserva requerida', '%', 'Porcentaje de la demanda que debe cubrir la reserva. Puede superar el 100 % en un experimento.', 0, None, 100),
}

GRUPOS = {
    'demanda_ct': ('Demanda máxima por centro', 'CT', ['DM']),
    'demanda_hora': ('Perfil horario de demanda', 'Hora', ['d']),
    'termicas': ('Centrales térmicas · A, C y F', 'Central', ['NMAXT', 'nminT', 'CMINT', 'CEXTT', 'CPMT']),
    'hidraulicas': ('Centrales hidráulicas · B y E', 'Central', ['NGH', 'CHH', 'CPMH', 'RNAH', 'NIH']),
    'nuclear': ('Central nuclear · D', 'Central', ['NMAXN', 'nminN', 'CMINN', 'CPMN']),
    'sos2': ('Curva nuclear · seis puntos SOS2', 'Punto', ['PEX', 'PREC']),
    'mercado': ('Mercado exterior · precios horarios', 'Hora', ['PC', 'PV']),
    'red': ('Red · capacidades por línea', 'Línea', ['CAP']),
}
ESCALARES = ['LIH', 'LSH', 'ES', 'MB', 'PR']


def extraer_datos(model):
    datos = {}
    for p in model.component_objects(Param):
        if p.mutable:
            datos[p.name] = ({k: float(value(p[k])) for k in p} if p.is_indexed()
                             else float(value(p)))
    if set(datos) != set(META):
        raise ValueError('Los parámetros mutables de App.py no coinciden con los de la interfaz.')
    return datos


def tabla_grupo(datos, grupo):
    _, indice, parametros = GRUPOS[grupo]
    claves = list(datos[parametros[0]])
    return pd.DataFrame({indice: claves, **{
        p: [datos[p][k] * META[p][5] for k in claves] for p in parametros
    }})


def aplicar_tabla(datos, grupo, tabla):
    _, indice, parametros = GRUPOS[grupo]
    for p in parametros:
        datos[p] = {}
        for fila in tabla.to_dict('records'):
            try:
                numero = float(fila[p]) / META[p][5]
            except (TypeError, ValueError):
                numero = float('nan')
            datos[p][fila[indice]] = numero


def validar(datos, originales):
    errores, avisos = [], []
    if set(datos) != set(originales):
        return ['Faltan parámetros o hay parámetros no reconocidos.'], []
    for p, ref in originales.items():
        actual = datos[p]
        if isinstance(ref, dict):
            if not isinstance(actual, dict) or set(actual) != set(ref):
                errores.append(f'{p}: los índices o dimensiones no son los originales.')
                continue
            valores = list(actual.items())
        else:
            valores = [(None, actual)]
        for k, v in valores:
            etiqueta, unidad, _, minimo, maximo, factor = META[p]
            nombre = f'{etiqueta} [{k}]' if k is not None else etiqueta
            if isinstance(v, bool) or not isinstance(v, (float, int)) or not math.isfinite(v):
                errores.append(f'{nombre}: introduce un número finito, sin celdas vacías.')
            elif (minimo is not None and v * factor < minimo) or (maximo is not None and v * factor > maximo):
                errores.append(f'{nombre}: valor fuera del rango permitido ({unidad}).')
    if errores:
        return errores, avisos
    if datos['LIH'] > datos['LSH']:
        errores.append('El nivel mínimo no puede superar el nivel máximo.')
    for h, v in datos['NIH'].items():
        if not datos['LIH'] <= v <= datos['LSH']:
            errores.append(f'Embalse {h}: el nivel inicial debe estar entre el mínimo y el máximo.')
    puntos = list(datos['PEX'].values())
    if puntos[0] != 0 or any(b <= a for a, b in zip(puntos, puntos[1:])):
        errores.append('SOS2: la potencia extra debe comenzar en cero y crecer estrictamente por punto.')
    techo = datos['NMAXN']['D'] * (1 - datos['nminN']['D'])
    if techo > puntos[-1] + 1e-9:
        avisos.append('La curva SOS2 no llega a toda la potencia extra nuclear disponible: limitará la generación. Puedes ampliar PEX si ese es tu experimento.')
    if any(datos['PV'][i] > datos['PC'][i] for i in datos['PC']):
        avisos.append('Hay horas con precio de venta mayor que el de compra. App.py permite comprar y vender en centros distintos; conserva esa posibilidad.')
    if any(datos[p][k] == 0 for p in ['CPMT', 'CPMH', 'CPMN'] for k in datos[p]):
        avisos.append('Con coste de arranque cero, algunas variables de arranque pueden valer 1 sin una transición real. Se conservan las restricciones originales.')
    return errores, avisos


def huella(datos):
    return hashlib.sha256(json.dumps(datos, sort_keys=True, allow_nan=True).encode()).hexdigest()


def desactualizado(ejecucion, datos):
    # Los índices ya están normalizados al leer JSON; la igualdad numérica exacta
    # admite 10 y 10.0, sin tolerancias ni redondeos que oculten una edición.
    return bool(ejecucion and (not ejecucion_vigente(ejecucion) or ejecucion.get('parametros') != datos))
