"""Costes y embalses: presentación de instantáneas óptimas, sin llamar al solver."""
from functools import lru_cache
import math
import pandas as pd
import altair as alt
import streamlit as st
from pyomo.environ import value
from motor import cargar_motor
from version_modelo import SHA_MODELO
from presentacion import formato, tarjetas, tabla

LOCALE={'number':{'decimal':',','thousands':'.','grouping':[3],'currency':['',' €']}}
COMPONENTES=[
    ('Funcionamiento y mínimos', ['Térmicas · mínimo','Hidráulicas · funcionamiento','Nuclear · mínimo'],
     'Costes CMINT, CHH y CMINN multiplicados por los estados de generación de cada hora.'),
    ('Producción adicional', ['Térmicas · extra','Nuclear · extra'],
     'Térmicas: potencia sobre el mínimo por CEXTT. Nuclear: CEXTN, interpolado mediante SOS2; no se aplica un precio medio nuevo.'),
    ('Arranques', ['Térmicas · arranque','Hidráulicas · arranque','Nuclear · arranque'],
     'Costes CPMT, CPMH y CPMN por las variables de arranque de cada central.'),
    ('Compras exteriores', ['Mercado · compra'],
     'PC por energía comprada en los dos puntos exteriores, considerando la duración del periodo.'),
    ('Ventas exteriores', ['Mercado · venta (ingreso negativo)'],
     'Menos PV por energía vendida. Un ingreso resta; si PV es negativo, vender supone un gasto.'),
]


@lru_cache
def duracion_periodo(firma=SHA_MODELO):
    # Delta_t no es editable. Se lee del modelo actual, nunca se presupone 1 h.
    return float(value(cargar_motor().model.Delta_t))


def preparar_costes(e):
    r=e['resultados'];p=e['parametros'];costes=r['tablas']['costes'].set_index('Concepto')['Coste (€)']
    esperados=[c for _,cs,_ in COMPONENTES for c in cs]
    if set(costes.index)!=set(esperados):raise ValueError('El desglose no coincide con los conceptos del modelo actual.')
    filas=[];acumulado=0.
    for orden,(nombre,conceptos,ayuda) in enumerate(COMPONENTES):
        importe=math.fsum(float(costes[c]) for c in conceptos);anterior=acumulado;acumulado+=importe
        filas.append({'Concepto':nombre,'Importe (€)':importe,'Desde':anterior,'Hasta':acumulado,
                      'Orden':orden,'Tipo':'Gasto (+)' if importe>=0 else 'Ingreso (−)','Explicación':ayuda})
    objetivo=r['coste_total']
    if abs(acumulado-objetivo)>1e-5:raise ValueError('El desglose no coincide con la función objetivo.')
    filas.append({'Concepto':'Coste neto total','Importe (€)':objetivo,'Desde':0.,'Hasta':objetivo,
                  'Orden':len(filas),'Tipo':'Total','Explicación':'Función objetivo evaluada para esta solución; no es otro coste que se sume.'})
    cascada=pd.DataFrame(filas)
    cascada['Importe mostrado']=cascada['Importe (€)'].map(lambda x:formato(x)+' €')
    t=r['tablas']['todas_las_variables'];variables={(x['Variable'],str(x['Elemento']),x['Hora']):x['Valor'] for x in t.to_dict('records')}
    def v(n,c,h):return variables[n,c,h]
    detalle=[]
    for c in 'ABCDEF':
        for h in r['horas']['hora']:
            if c in p['NMAXT']:
                fijo=p['CMINT'][c]*v('alphaT',c,h)
                extra=p['CEXTT'][c]*(v('PT',c,h)-p['nminT'][c]*p['NMAXT'][c]*v('alphaT',c,h))
                arranque=p['CPMT'][c]*v('aT',c,h)
            elif c in p['NGH']:
                fijo=p['CHH'][c]*v('alphaH',c,h);extra=0.;arranque=p['CPMH'][c]*v('aH',c,h)
            else:
                fijo=p['CMINN'][c]*v('alphaN',c,h);extra=v('CEXTN',c,h);arranque=p['CPMN'][c]*v('aN',c,h)
            detalle.append({'Central':c,'Hora':h,'Funcionamiento y mínimos (€)':fijo,
                            'Producción adicional (€)':extra,'Arranques (€)':arranque,'Coste directo (€)':fijo+extra+arranque})
    detalle=pd.DataFrame(detalle)
    centrales=detalle.drop(columns='Hora').groupby('Central',sort=False,as_index=False).sum()
    if abs(centrales['Coste directo (€)'].sum()-sum(x['Importe (€)'] for x in filas[:3]))>1e-5:
        raise ValueError('Los costes por central no coinciden con el desglose.')
    return cascada,centrales,detalle


def grafico_cascada(datos):
    d=datos.copy()
    d['Etiqueta']=[('Total: ' if t=='Total' else '+' if v>0 else '−' if v<0 else '')+formato(abs(v) if t!='Total' else v)+' €' for v,t in zip(d['Importe (€)'],d.Tipo)]
    # Banda propia para cifras: legibles incluso en pasos muy pequeños o negativos.
    orden=d.Concepto.tolist()
    base=alt.Chart(d).encode(y=alt.Y('Concepto:N',sort=orden,axis=None))
    barras=base.mark_bar(size=22,cornerRadius=3).encode(
        x=alt.X('Desde:Q',title='Coste acumulado (€)',axis=alt.Axis(format=',.0f',tickCount=3,labelOverlap='greedy')),x2='Hasta:Q',
        color=alt.Color('Tipo:N',scale=alt.Scale(domain=['Gasto (+)','Ingreso (−)','Total'],range=['#638398','#3E8674','#233F52']),legend=alt.Legend(orient='bottom',title=None)),
        tooltip=['Concepto:N','Importe mostrado:N','Explicación:N'])
    # Los conectores siguen el acumulado; el total final parte de cero.
    pasos=d.iloc[:-2].copy();pasos['Siguiente']=d.Concepto.shift(-1).iloc[:-2]
    conectores=alt.Chart(pasos).mark_rule(strokeDash=[3,3],color='#8B9DA8').encode(
        x='Hasta:Q',y=alt.Y('Concepto:N',sort=orden,axis=None),y2='Siguiente:N')
    nombres=base.mark_text(align='left',dy=-19,fontSize=12,fontWeight=600,color='#233F52').encode(x=alt.value(0),text='Concepto:N')
    cifras=base.mark_text(align='right',dy=-19,fontSize=12,fontWeight=600,color='#233F52').encode(x=alt.value('width'),text='Etiqueta:N')
    return (conectores+barras+nombres+cifras).properties(height=460).configure(locale=LOCALE)


def grafico_centrales(datos):
    campos=['Funcionamiento y mínimos (€)','Producción adicional (€)','Arranques (€)']
    largo=datos.melt('Central',value_vars=campos,var_name='Concepto',value_name='Coste')
    largo['Importe']=largo.Coste.map(lambda v:formato(v)+' €')
    barras=alt.Chart(largo).mark_bar(size=24).encode(
        y=alt.Y('Central:N',sort=list('ABCDEF'),title='Central'),x=alt.X('Coste:Q',title='Coste directo (€)',axis=alt.Axis(format=',.0f',tickCount=3,labelOverlap='greedy')),
        color=alt.Color('Concepto:N',scale=alt.Scale(domain=campos,range=['#365B70','#85A9B3','#C6A16D']),legend=alt.Legend(orient='bottom',columns=1,title=None,labelLimit=0)),
        tooltip=['Central:N','Concepto:N','Importe:N'])
    totales=datos.copy();totales['Total mostrado']=totales['Coste directo (€)'].map(lambda v:formato(v)+' €')
    etiquetas=alt.Chart(totales).mark_text(align='right',dy=-18,fontSize=12,color='#233F52',fontWeight=600).encode(
        y=alt.Y('Central:N',sort=list('ABCDEF')),x=alt.value('width'),text='Total mostrado:N')
    return (barras+etiquetas).properties(height=440).configure(locale=LOCALE)


def mostrar_costes(e):
    st.markdown('#### Cómo se compone el coste neto')
    try:cascada,centrales,detalle=preparar_costes(e)
    except (ValueError,KeyError) as exc:
        st.error(f'No se puede representar el desglose: {exc}');return
    st.altair_chart(grafico_cascada(cascada),width='stretch',key='coste_cascada')
    st.caption('Cada barra parte del acumulado anterior; la última muestra el total desde cero. Los ingresos restan. Las cifras y explicaciones completas se consultan sobre las barras o en el detalle.')
    gastos=cascada.iloc[:-1];mayor=gastos.loc[gastos['Importe (€)'].idxmax()]
    if mayor['Importe (€)']>0:st.write(f"Mayor componente de gasto: **{mayor['Concepto']}**, {formato(mayor['Importe (€)'])} €.")
    st.markdown('#### Coste directamente atribuible a cada central')
    st.altair_chart(grafico_centrales(centrales),width='stretch',key='coste_centrales')
    st.caption('Incluye funcionamiento/mínimos, producción adicional y arranques. Las compras y ventas exteriores no se reparten entre centrales. El bombeo no añade un coste independiente: se abastece con la generación y las compras ya contabilizadas.')
    with st.expander('Detalle verificable de los costes'):
        tabla('cascada_costes',cascada[['Concepto','Importe (€)','Explicación']])
        tabla('costes_por_central',centrales)
        tabla('costes_central_hora',detalle)
        # Se conservan las tablas y descargas anteriores.
        tabla('costes',e['resultados']['tablas']['costes'])
        tabla('costes_por_hora',e['resultados']['tablas']['costes_por_hora'])


def preparar_embalse(e,c,dt=None):
    dt=duracion_periodo() if dt is None else dt
    if dt<=0:raise ValueError('Duración del periodo no válida.')
    h=e['resultados']['horas'].sort_values('hora');p=e['parametros'];inicial=p['NIH'][c]
    niveles=pd.DataFrame({'Tiempo':[0.]+[(i+1)*dt for i in h.hora],
        'Nivel':[inicial]+h['nivel_'+c].tolist(),
        'Momento':['Inicial · antes de la hora 0']+[f'Final del periodo {i}' for i in h.hora]})
    niveles['Nivel mostrado']=niveles.Nivel.map(lambda v:formato(v,4)+' m')
    filas=[]
    for fila in h.to_dict('records'):
        for tipo,potencia in [('Generación',fila[c]),('Bombeo',fila['bombeo_'+c])]:
            filas.append({'Hora':fila['hora'],'Inicio':fila['hora']*dt,'Fin':(fila['hora']+1)*dt,
                          'Operación':tipo,'Potencia':potencia if tipo=='Generación' else -potencia,
                          'Potencia original (MW)':potencia,'Potencia mostrada':formato(potencia)+' MW'})
    resumen={'inicial':inicial,'final':float(niveles.Nivel.iloc[-1]),'variacion':float(niveles.Nivel.iloc[-1])-inicial,
        'generada':float(h[c].sum())*dt,'bombeada':float(h['bombeo_'+c].sum())*dt,
        'inferior':p['LIH'],'superior':p['LSH'],'duracion':dt,'fin_dia':float(niveles.Tiempo.iloc[-1])}
    return niveles,pd.DataFrame(filas),resumen


def grafico_embalse(niveles,potencias,resumen,ampliada=False):
    inferior=min(niveles.Nivel);superior=max(niveles.Nivel)
    if not ampliada:inferior=min(inferior,resumen['inferior']);superior=max(superior,resumen['superior'])
    margen=max((superior-inferior)*.08,.0001 if ampliada else .02)
    dominio=[inferior-margen,superior+margen]
    escala=alt.Scale(domain=dominio,zero=False,nice=False)
    eje=alt.Axis(values=[0,4,8,12,16,20,24] if resumen['fin_dia']==24 else None)
    x=alt.X('Tiempo:Q',title=None,scale=alt.Scale(domain=[0,resumen['fin_dia']]),axis=eje)
    line=alt.Chart(niveles).mark_line(strokeWidth=2.5,color='#287D81',point=alt.OverlayMarkDef(size=24),clip=True).encode(
        x=x,y=alt.Y('Nivel:Q',title='Nivel (m)',scale=escala,axis=alt.Axis(format='.4f' if ampliada and superior-inferior<.1 else '.2f',tickCount=5,minExtent=55,maxExtent=55)),
        tooltip=['Momento:N',alt.Tooltip('Tiempo:Q',title='Tiempo transcurrido (h)'), 'Nivel mostrado:N'])
    referencias=pd.DataFrame({'Nivel':[resumen['inferior'],resumen['superior'],resumen['inicial']],
                              'Referencia':['Límite inferior','Límite superior','Nivel inicial']})
    referencias['Valor']=referencias.Nivel.map(lambda v:formato(v,3)+' m')
    limites=alt.Chart(referencias).mark_rule(clip=True).encode(
        y=alt.Y('Nivel:Q',scale=escala),
        strokeDash=alt.StrokeDash('Referencia:N',scale=alt.Scale(domain=referencias.Referencia.tolist(),range=[[3,3],[3,3],[9,4]]),legend=alt.Legend(orient='bottom',columns=1,title=None,labelLimit=0)),
        color=alt.value('#8995A1'),
        tooltip=['Referencia:N','Valor:N'])
    nivel=(line+limites).properties(height=330,width='container',title='Nivel · escala ampliada' if ampliada else 'Nivel · escala general con límites')
    barras=alt.Chart(potencias).transform_filter('datum.Potencia != 0').mark_bar(clip=True,opacity=.9).encode(
        x=alt.X('Inicio:Q',title='Tiempo transcurrido desde el inicio del día (h)',scale=alt.Scale(domain=[0,resumen['fin_dia']]),axis=eje),x2='Fin:Q',
        y=alt.Y('Potencia:Q',title='Potencia (MW)',axis=alt.Axis(tickCount=5,minExtent=55,maxExtent=55)),
        color=alt.Color('Operación:N',scale=alt.Scale(domain=['Generación','Bombeo'],range=['#287D81','#B58A56']),legend=alt.Legend(orient='bottom',title=None)),
        tooltip=[alt.Tooltip('Hora:Q',title='Periodo'), 'Operación:N','Potencia mostrada:N']).properties(height=300,width='container',title='Operación eléctrica · bombeo bajo cero')
    return alt.vconcat(nivel,barras,spacing=14).resolve_scale(x='shared',color='independent').configure(locale=LOCALE)


def mostrar_embalses(e):
    st.caption('NAH es el nivel al final de cada periodo. El punto de tiempo 0 es NIH, antes de la primera hora. El nivel inicial es una referencia: no hay obligación de recuperarlo al final del día.')
    for c in ('B','E'):
        st.markdown(f'#### Central {c} · agua y operación eléctrica')
        niveles,potencias,r=preparar_embalse(e,c)
        tarjetas([('Nivel inicial',formato(r['inicial'],3),'m','Antes de comenzar el primer periodo.'),
                  ('Nivel final',formato(r['final'],3),'m','Al terminar el último periodo.'),
                  ('Variación del nivel',formato(r['variacion'],3),'m','Nivel final menos nivel inicial.'),
                  ('Energía generada',formato(r['generada'],2),'MWh',f"Suma de potencias por {formato(r['duracion'])} h por periodo."),
                  ('Energía de bombeo',formato(r['bombeada'],2),'MWh','Consumo eléctrico acumulado, sin convertirlo en volumen de agua.')],compactas=True)
        ampliada=st.radio(f'Escala del nivel · {c}',['General · incluye límites','Ampliada · variaciones reales'],horizontal=True,key='escala_embalse_'+c).startswith('Ampliada')
        graficos=grafico_embalse(niveles,potencias,r,ampliada)
        # Dos vistas con dominio y margen izquierdo iguales: Streamlit puede
        # ajustar cada una al ancho disponible sin desbordar un vconcat.
        for parte,grafico in zip(('nivel','potencia'),graficos.vconcat):
            st.altair_chart(grafico.configure(locale=LOCALE),width='stretch',key='operacion_embalse_'+c+'_'+parte)
        st.caption(f"Límites del escenario: {formato(r['inferior'],3)}–{formato(r['superior'],3)} m. Bombeo bajo cero solo como convención gráfica: el consumo del modelo es positivo. Los dos gráficos comparten el tiempo; cada barra abarca el periodo completo.")
        if ampliada:st.info('Escala ampliada: los límites pueden quedar fuera del encuadre. La escala general permite ver el rango permitido completo.')
    with st.expander('Tabla de embalses · valores originales y descarga'):
        tabla('embalses',e['resultados']['tablas']['embalses'])
