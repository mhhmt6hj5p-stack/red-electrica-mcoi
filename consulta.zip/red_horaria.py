"""Datos de la red por hora. Solo lectura de topología y resultados guardados."""
from pyomo.environ import value
from pyomo.core.expr.visitor import identify_variables
from motor import cargar_motor

TOL_FLUJO = 1e-6  # MW; solo para flechas, estados textuales y avisos, nunca para editar datos.
UMBRAL_PROXIMIDAD = 95.0  # porcentaje de la capacidad nominal de una línea.


def extraer_topologia(modelo=None):
    m = modelo if modelo is not None else cargar_motor().model
    horas = list(m.I)
    assert horas == list(range(24)) and value(m.Delta_t) == 1
    def flujos(restriccion):
        return {v.index()[0] for v in identify_variables(restriccion.body)
                if v.parent_component() is m.F}
    tipos = {**{c:'Térmica' for c in m.T}, **{c:'Hidráulica reversible' for c in m.H},
             **{c:'Nuclear' for c in m.N}}
    origenes = {}
    for c in tipos:
        for l in flujos(getattr(m,'balance_'+c)[horas[0]]):
            assert l not in origenes
            origenes[l] = c
    for c in m.CEXT:
        for l in flujos(getattr(m,'flujo_exterior_CT'+str(c))[horas[0]]):
            assert l not in origenes
            origenes[l] = 'EXT'+str(c)
    destinos = {}
    for c in m.C:
        for l in flujos(getattr(m,'balance_CT'+str(c))[horas[0]]):
            assert l not in destinos
            destinos[l] = 'CT'+str(c)
    assert set(origenes)==set(destinos)==set(m.L)
    nodos = [{'id':c,'tipo':tipos[c]} for c in sorted(tipos)]
    nodos += [{'id':'CT'+str(c),'tipo':'Centro de transformación','centro':int(c)} for c in m.C]
    nodos += [{'id':'EXT'+str(c),'tipo':'Mercado exterior','centro':int(c)} for c in m.CEXT]
    return {'nodos':nodos, 'lineas':[{'id':l,'origen':origenes[l],'destino':destinos[l]} for l in m.L],
            'horas':horas, 'duracion_h':value(m.Delta_t)}


def intervalo(hora):
    return f'{hora:02d}:00–{hora+1:02d}:00 · hora {hora}'


def preparar_hora(ejecucion, hora, topologia):
    """No recibe datos editables: todo procede de la instantánea resuelta."""
    r=ejecucion['resultados'];p=ejecucion['parametros']
    h=r['horas'].set_index('hora').loc[hora]
    t=r['tablas']['todas_las_variables']
    variables={(fila['Variable'],str(fila['Elemento'])):float(fila['Valor'])
               for fila in t[t['Hora']==hora].to_dict('records')}
    def v(nombre,elemento):return variables[nombre,str(elemento)]
    fs=r['tablas']['flujos'].set_index('Hora').loc[hora]
    demanda=r['tablas']['demanda_por_centro']
    demanda=demanda[demanda['Hora']==hora].set_index('CT')
    lineas=[]
    for l in topologia['lineas']:
        nombre=l['id'];c=l['origen'];f=float(fs[nombre+' (MW)']);cap=p['CAP'][nombre]
        if c in p['NGH']:
            inferior=-cap*v('alphaBH',c);superior=cap*v('alphaH',c)
        elif c in p['NMAXT'] or c in p['NMAXN']:
            inferior=0.;superior=cap
        else:inferior=-cap;superior=cap
        signo=1 if f>TOL_FLUJO else -1 if f < -TOL_FLUJO else 0
        limite=superior if f>0 else -inferior if f<0 else max(superior,-inferior)
        lineas.append({**l,'flujo':f,'capacidad':cap,'inferior':inferior,'superior':superior,
                       'utilizacion':abs(f)/cap*100 if cap>0 else None,
                       'margen':limite-abs(f),'signo':signo,
                       'desde':c if signo>=0 else l['destino'],
                       'hasta':l['destino'] if signo>=0 else c})
    nodos=[]
    for n in topologia['nodos']:
        c=n['id'];d=dict(n)
        if n['tipo'] in ('Térmica','Nuclear'):
            sufijo='T' if n['tipo']=='Térmica' else 'N'
            a=v('alpha'+sufijo,c);mx=p['NMAX'+sufijo][c];mn=mx*p['nmin'+sufijo][c]
            d.update(produccion=v('P'+sufijo,c),estado='Encendida' if a>.5 else 'Apagada',
                     encendida=a,arranque=v('a'+sufijo,c),minimo=mn*a,maximo=mx*a,
                     nominal=mx,minimo_tecnico=mn)
            if sufijo=='N':
                d['maximo_sos2']=min(mx*a,mn*a+max(p['PEX'].values())*a)
        elif n['tipo']=='Hidráulica reversible':
            a=v('alphaH',c);b=v('alphaBH',c)
            estado='Generación habilitada' if a>.5 else 'Bombeo habilitado' if b>.5 else 'Parada'
            d.update(produccion=v('PH',c),estado=estado,encendida=a,bombeo_habilitado=b,
                     arranque=v('aH',c),bombeo=v('PB',c),nivel=v('NAH',c),
                     nivel_inicial=p['NIH'][c],nivel_min=p['LIH'],nivel_max=p['LSH'],
                     minimo=p['NGH'][c]*a,maximo=p['NGH'][c]*a,
                     max_bombeo=p['MB']*b,nominal=p['NGH'][c])
        elif n['tipo']=='Centro de transformación':
            ct=n['centro'];entrada=sum(l['flujo'] for l in lineas if l['destino']==c)
            d.update(demanda=float(demanda.loc[ct,'Demanda (MW)']),entrada=entrada,
                     residual=entrada-float(demanda.loc[ct,'Demanda (MW)']))
            if ('COMP',str(ct)) in variables:
                d.update(compra=v('COMP',ct),venta=v('VENT',ct))
        else:
            ct=n['centro'];d.update(compra=v('COMP',ct),venta=v('VENT',ct),
                compra_habilitada=v('betaCOMP',ct),venta_habilitada=v('betaVENT',ct))
        nodos.append(d)
    indicadores={k:float(h[k]) for k in ('demanda','generacion','compra','venta','bombeo',
                                       'reserva_total','reserva_requerida','margen_reserva')}
    balance=indicadores['generacion']+indicadores['compra']-indicadores['demanda']-indicadores['venta']-indicadores['bombeo']
    return {'hora':hora,'nodos':nodos,'lineas':lineas,'indicadores':indicadores,'balance':balance,
            'tolerancia_balance':float(r['verificacion']['tolerancia_factibilidad'])*len(topologia['nodos'])}
