"""Vista por horas: SVG seleccionable y detalle de una instantánea, sin solver."""
from html import escape
from math import hypot
import pandas as pd
import streamlit as st
from streamlit.components.v2 import component
from escenarios import es_optimo
from datos import desactualizado
from version_modelo import SHA_MODELO, version_ejecucion
from presentacion import formato, fecha_legible, tabla, grafico_lineas
from red_horaria import extraer_topologia, preparar_hora, intervalo, TOL_FLUJO, UMBRAL_PROXIMIDAD

# Unidades del viewBox, independientes del grosor del trazo y del zoom.
TAMANO_FLECHA=12*1.3

# Composición no geográfica. Los extremos siguen procediendo de los balances.
POSICIONES={'A':(105,330),'B':(650,75),'C':(1160,330),'D':(760,290),
            'E':(780,475),'F':(650,665),'CT1':(340,135),'CT2':(940,135),
            'CT3':(1000,575),'CT4':(550,360),'CT5':(300,575),
            'EXT1':(120,100),'EXT5':(110,700)}
ESTILOS_NODO={'Térmica':('#F1F5F8','#47657A','TÉRMICA'),
               'Hidráulica reversible':('#ECF6F3','#357C70','HIDROELÉCTRICA'),
               'Nuclear':('#F1EFF7','#75688C','NUCLEAR'),
               'Centro de transformación':('#FFFFFF','#536A7D','CENTRO'),
               'Mercado exterior':('#F8F3EA','#8A744F','EXTERIOR')}
CSS="""
.red-root{container-type:inline-size;font-family:inherit;color:#1C3448}
.red-root.ampliada,.red-root:fullscreen,:host(:fullscreen) .red-root{background:#F3F6F9;width:100vw;height:100vh;overflow:auto;padding:22px;box-sizing:border-box}
.red-layout{display:grid;grid-template-columns:1fr;gap:16px}
.red-dibujo,.red-panel,.red-detalle{min-width:0;background:#fff;border:1px solid #D7E1E8;border-radius:14px;padding:18px}
.red-toolbar{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px 12px;align-items:start;position:sticky;top:60px;background:#fff;z-index:3;padding:6px 0}
.red-root.ampliada .red-toolbar{top:0}
.red-grupo{min-width:0;border:1px solid #DFE7ED;border-radius:9px;padding:7px 9px;background:#FBFCFD}
.red-grupo h5{font:inherit;font-size:11px;font-weight:600;letter-spacing:.03em;color:#526777;margin:0 0 6px}
.red-acciones{display:flex;flex-wrap:wrap;align-items:center;gap:6px}
.red-grupo-vista{grid-column:1;grid-row:1}.red-grupo-horas{grid-column:1;grid-row:2}.red-grupo-textura{grid-column:2;grid-row:1 / span 2;align-self:stretch}
.red-grupo-textura p{font-size:12px;line-height:1.4;color:#526777;margin:7px 0 0;max-width:145px}
.controles-hora{display:flex;gap:5px;align-items:center;flex-wrap:wrap;min-width:0}
.red-toolbar button,.red-toolbar select{font:inherit;font-size:13px;line-height:1.4;min-height:36px;max-width:100%;white-space:normal;background:#F6F9FB;border:1px solid #CAD7E0;border-radius:7px;padding:8px 10px;color:#213F53;cursor:pointer}
.red-toolbar .primario{background:#214E65;color:white;border-color:#214E65}
.red-root.movimiento-reducido path[data-corriente]{stroke:var(--color-linea)}
.relleno-central{transform-box:fill-box;transform-origin:50% 100%;pointer-events:none}
.red-toolbar button:focus-visible,.red-toolbar select:focus-visible{outline:3px solid #24748D;outline-offset:2px}.red-toolbar button:disabled{opacity:.45;cursor:default}.red-toolbar .volver,.solo-ampliada{display:none}
.red-root.ampliada .solo-ampliada,.red-root:fullscreen .solo-ampliada,:host(:fullscreen) .solo-ampliada{display:block}.red-root.ampliada .volver,.red-root:fullscreen .volver,:host(:fullscreen) .volver{display:inline-block}.red-root.ampliada .ampliar,.red-root:fullscreen .ampliar,:host(:fullscreen) .ampliar{display:none}
.red-cabecera{display:flex;justify-content:space-between;gap:14px;flex-wrap:wrap;font-size:14px;color:#587083;margin-bottom:8px}
.red-cabecera b{color:#203E52;font-size:15px;letter-spacing:.07em}
.red-lienzo{overflow:auto;border:1px solid #E4EBF0;border-radius:10px;background:#FBFCFD}
.red-lienzo svg{display:block;width:100%;min-width:0;height:auto;max-width:none}
svg [role=button]{cursor:pointer;outline:none}svg [role=button]:focus .forma:not([data-corriente]),svg [role=button]:hover .forma:not([data-corriente]){stroke:#1A6D9B;stroke-width:3}
svg [role=button]:focus path[data-corriente],svg [role=button]:hover path[data-corriente]{stroke-width:7}
svg text{font-family:Arial,sans-serif}.leyenda{font-size:13px;line-height:1.7;display:flex;gap:8px 18px;flex-wrap:wrap;padding-top:12px}
.red-ayuda{font-size:13px;color:#566E80;margin:8px 0}.red-panel h4,.red-detalle h4{margin:0 0 12px;font-size:18px}
.red-root.defensa .red-ayuda:not(.solo-ampliada){display:none}
.indicadores{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px}
.indicador{background:#F3F7FA;border-radius:8px;padding:12px;overflow-wrap:anywhere}
.indicador span{display:block;font-size:13px;color:#526777}.indicador strong{display:block;font-size:22px;line-height:1.5;font-variant-numeric:tabular-nums}.indicador small{font-size:13px;font-weight:400}
.balance{background:#EEF6F3;padding:12px;border-radius:8px;font-size:14px;margin-top:12px}
.red-panel ul{padding-left:20px;font-size:14px;line-height:1.6}.red-detalle p,.red-detalle table{font-size:14px;line-height:1.6}
.red-detalle table{border-collapse:collapse;width:100%}.red-detalle th,.red-detalle td{text-align:left;padding:6px 10px;border-bottom:1px solid #E2EAF0}
@container(max-width:650px){.indicadores{grid-template-columns:repeat(2,minmax(0,1fr))}.red-dibujo,.red-panel,.red-detalle{padding:12px}.red-toolbar button{padding:9px}}
@container(max-width:820px){.red-toolbar{grid-template-columns:minmax(0,1fr)}.red-grupo-vista,.red-grupo-horas,.red-grupo-textura{grid-column:1;grid-row:auto}.red-grupo-textura{display:flex;align-items:center;flex-wrap:wrap;gap:6px 14px}.red-grupo-textura h5{margin:0}.red-grupo-textura p{margin:0;max-width:none}}
@container(min-width:1200px){.red-toolbar{grid-template-columns:minmax(0,.9fr) minmax(0,1.2fr) auto}.red-grupo-vista,.red-grupo-horas,.red-grupo-textura{grid-row:1}.red-grupo-horas{grid-column:2}.red-grupo-textura{grid-column:3}}
@media(prefers-reduced-motion:reduce){path[data-corriente]{stroke:var(--color-linea)}}
"""
# La capa ampliada se monta fuera del nodo que Streamlit sustituye al actualizar
# resultados. Así conserva pantalla completa, encuadre y selección entre horas.
JS="""export default function({data, parentElement, setTriggerValue}) {
 const normal=parentElement.querySelector('.red-root');
 const id='mcoi-red-pantalla-ampliada';
 // Estado visual local: persiste cuando Streamlit sustituye el componente.
 // No se envían eventos ni consultas al servidor para animar o pausar.
 const estado=document._mcoiRedEfectos||(document._mcoiRedEfectos={pausado:false,rellenos:{}});
 estado.normal=normal;
 const anteriores=estado.rellenos,siguientes={};
 if(estado.firma!==data.firma){estado.reproduciendo=false;estado.firma=data.firma;}
 if(estado.horas!=null)window.clearTimeout(estado.horas);estado.horas=null;
 const reduccion=window.matchMedia('(prefers-reduced-motion: reduce)');
 // Un solo temporizador local (30 fps). Safari puede suspender requestAnimationFrame
 // en esta vista; el temporizador mantiene el avance sin consultas al servidor.
 // Solo se modifican atributos del degradado del trazo continuo.
 function actualizarTexturas(root){
  (root._corrientes||[]).forEach(c=>{
   const fase=((estado.tiempo||0)%c.duracion)/c.duracion;
   c.elemento.setAttribute('gradientTransform',`translate(${c.dx*fase} ${c.dy*fase})`);
  });
 }
 function animar(){
  if(estado.temporizador!=null)window.clearTimeout(estado.temporizador);
  estado.temporizador=null;
  if(estado.pausado||reduccion.matches)return;
  let anterior=null;
  const paso=ahora=>{
   estado.temporizador=null;
   const activas=vistas().filter(root=>root.isConnected&&root.style.visibility!=='hidden'&&(root._corrientes||[]).length);
   if(estado.pausado||reduccion.matches||!activas.length)return;
   // Usar tiempo real: si Safari limita la frecuencia en segundo plano, no
   // ralentizar además la corriente. Al reanudar, el primer paso conserva la fase.
   if(anterior!==null)estado.tiempo=(estado.tiempo||0)+Math.max(0,ahora-anterior);
   anterior=ahora;activas.forEach(actualizarTexturas);
   estado.temporizador=window.setTimeout(()=>paso(window.performance.now()),1000/30);
  };
  estado.temporizador=window.setTimeout(()=>paso(window.performance.now()),1000/30);
 }
 function movimiento(root){
  const reducido=reduccion.matches,pausado=estado.pausado||reducido;
  root.classList.toggle('movimiento-reducido',reducido);
  const svg=root.querySelector('svg');
  const boton=root.querySelector('.movimiento');
  const hayFlujo=!!(root._corrientes||[]).length;
  boton.textContent=!hayFlujo?(svg.dataset.solucion==='si'?'Sin flujo apreciable':'Sin solución'):reducido?'Movimiento reducido':pausado?'Activar movimiento':'Pausar movimiento';
  boton.setAttribute('aria-pressed',String(hayFlujo&&!pausado));boton.disabled=reducido||!hayFlujo;
  boton.title=reducido?'Se respeta la preferencia de movimiento reducido del navegador.':'Solo controla la textura de las líneas; no cambia los datos ni ejecuta el modelo.';
  if(reducido)root.querySelectorAll('.relleno-central').forEach(el=>el.getAnimations().forEach(a=>a.finish()));
 }
 function vistas(){const portal=document.getElementById(id);return [estado.normal,portal?.shadowRoot.querySelector('.red-root')].filter(Boolean);}
 function cerrar(portal){
  if(portal._resize)window.removeEventListener('resize',portal._resize);
  if(portal._observador)portal._observador.disconnect();
  if(portal._salida)document.removeEventListener('fullscreenchange',portal._salida);
  portal.remove();estado.normal.style.visibility='visible';
 }
 function actualizarReproduccion(){
  vistas().forEach(root=>{const b=root.querySelector('.reproduccion');
   b.textContent=estado.reproduciendo?'Pausar horas':data.hora===23?'Reproducir desde 00:00':'Reproducir horas';
   b.disabled=reduccion.matches||root.querySelector('svg').dataset.solucion!=='si';
   b.setAttribute('aria-pressed',String(!!estado.reproduciendo));
   root.querySelector('.velocidad-horas').value=String(estado.velocidad||2000);
  });
 }
 function programarHoras(){
  if(estado.horas!=null)window.clearTimeout(estado.horas);estado.horas=null;
  if(reduccion.matches)estado.reproduciendo=false;
  if(data.hora===23)estado.reproduciendo=false;
  actualizarReproduccion();
  if(!estado.reproduciendo)return;
  estado.horas=window.setTimeout(()=>{estado.horas=null;
   if(!vistas().some(root=>root.isConnected)){estado.reproduciendo=false;return;}
   setTriggerValue('hora',data.hora+1);
   // El siguiente paso se programa solo tras recibir y pintar la nueva hora.
  },estado.velocidad||2000);
 }
 function pintar(root,host,ampliada,transicionar=true){
  const previo=root.querySelector('.red-lienzo');
  const desplazamiento=previo?previo.scrollLeft:Number(host.dataset.desplazamiento||0);
  root.innerHTML=data.html;root.classList.toggle('ampliada',ampliada);root.classList.toggle('defensa',!!data.defensa);
  const lienzo=root.querySelector('.red-lienzo'),svg=lienzo.querySelector('svg');
  root._corrientes=Array.from(svg.querySelectorAll('linearGradient.textura-corriente')).map(el=>({
   elemento:el,dx:Number(el.dataset.dx),dy:Number(el.dataset.dy),duracion:Number(el.dataset.duracion)*1000}));
  actualizarTexturas(root);
  root.querySelectorAll('.relleno-central').forEach(el=>{
   const clave=el.dataset.central,actual=Number(el.dataset.fraccion);
   const previo=transicionar?(anteriores[clave]??actual):actual;siguientes[clave]=actual;
   if(!reduccion.matches&&previo!==actual)el.animate([{transform:`scaleY(${previo})`},{transform:`scaleY(${actual})`}],{duration:500,easing:'ease-out'});
  });
  movimiento(root);
  root.querySelector('.movimiento').onclick=()=>{estado.pausado=!estado.pausado;vistas().forEach(movimiento);animar();};
  if(!host.dataset.ajustar){host.dataset.ajustar='si';host.dataset.zoom=1;}
  root.querySelector('.reproduccion').onclick=()=>{
   if(!estado.reproduciendo&&data.hora===23){estado.reproduciendo=true;actualizarReproduccion();setTriggerValue('hora',0);return;}
   estado.reproduciendo=!estado.reproduciendo;programarHoras();
  };
  root.querySelector('.velocidad-horas').onchange=e=>{estado.velocidad=Number(e.target.value);programarHoras();};
  const encuadrar=()=>{const ajustar=host.dataset.ajustar==='si';
   let ancho=lienzo.clientWidth;const z=Number(host.dataset.zoom||1);
   // En escritorio, ajustar al ancho real, incluida la barra lateral abierta.
   // Una ventana estrecha conserva un tamaño legible y ofrece desplazamiento.
   if(!ajustar||(!ampliada&&ancho<680))ancho=Math.max(960,ancho);
   if(ampliada&&ajustar){const alto=Math.max(260,window.innerHeight-lienzo.getBoundingClientRect().top-85);ancho=Math.min(ancho,alto*1280/750);}
   svg.style.minWidth='0px';svg.style.width=(ancho*z)+'px';svg.style.margin='0 auto';};
  encuadrar();lienzo.scrollLeft=desplazamiento;lienzo.onscroll=()=>{host.dataset.desplazamiento=lienzo.scrollLeft;};
  if(host._resize)window.removeEventListener('resize',host._resize);host._resize=encuadrar;
  if(host._observador)host._observador.disconnect();host._observador=new ResizeObserver(encuadrar);host._observador.observe(lienzo);
  root.querySelectorAll('[data-elemento]').forEach(el=>{
   const elegir=()=>setTriggerValue('seleccion',el.dataset.elemento);
   el.onclick=elegir;el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();elegir();}};
  });
  root.querySelector('.ampliar').onclick=async()=>{
   let portal=document.getElementById(id);
   if(!portal){
    portal=document.createElement('div');portal.id=id;
    Object.assign(portal.style,{position:'fixed',inset:'0',zIndex:'2147483640',background:'#F3F6F9',overflow:'auto'});
    const shadow=portal.attachShadow({mode:'open'}),style=document.createElement('style');style.textContent=data.css;shadow.append(style);
    const vista=document.createElement('div');vista.className='red-root';shadow.append(vista);document.body.append(portal);
    portal.dataset.zoom=1;portal.dataset.ajustar='si';
    portal._salida=()=>{if(!document.fullscreenElement&&portal._entro)cerrar(portal);};document.addEventListener('fullscreenchange',portal._salida);
   }
   normal.style.visibility='hidden';pintar(portal.shadowRoot.querySelector('.red-root'),portal,true,false);animar();programarHoras();
   try{await portal.requestFullscreen();portal._entro=true;portal._resize();}
   catch(e){portal.shadowRoot.querySelector('.red-aviso').textContent='Vista ampliada dentro del navegador. Puedes volver con el botón superior.';}
  };
  root.querySelector('.volver').onclick=async()=>{if(document.fullscreenElement===host)await document.exitFullscreen();else cerrar(host);};
  root.querySelector('[data-zoom="mas"]').onclick=()=>{host.dataset.zoom=Math.min(2.5,Number(host.dataset.zoom||1)+.2);encuadrar();};
  root.querySelector('[data-zoom="menos"]').onclick=()=>{host.dataset.zoom=Math.max(.6,Number(host.dataset.zoom||1)-.2);encuadrar();};
  root.querySelector('[data-zoom="ajustar"]').onclick=()=>{host.dataset.zoom=1;host.dataset.ajustar='si';encuadrar();};
  root.querySelector('[data-zoom="leer"]').onclick=()=>{host.dataset.zoom=1;host.dataset.ajustar='no';encuadrar();};
  root.querySelectorAll('[data-hora]').forEach(el=>el.onclick=()=>setTriggerValue('hora',Math.max(0,Math.min(23,data.hora+Number(el.dataset.hora)))));
  root.querySelector('.hora-ampliada').onchange=e=>setTriggerValue('hora',Number(e.target.value));
 }
 pintar(normal,normal.getRootNode().host||normal,false);
 const portal=document.getElementById(id);normal.style.visibility=portal?'hidden':'visible';
 if(portal)pintar(portal.shadowRoot.querySelector('.red-root'),portal,true);
 estado.rellenos=siguientes;
 // Un único oyente activo, incluso después de varias selecciones de hora.
 if(estado.reduccion)estado.reduccion.media.removeEventListener('change',estado.reduccion.oir);
 const oir=()=>{vistas().forEach(movimiento);animar();programarHoras();};reduccion.addEventListener('change',oir);estado.reduccion={media:reduccion,oir};
 animar();programarHoras();
}"""
ESQUEMA=component('mcoi_red_horaria',html='<div class="red-root"></div>',css=CSS,js=JS)


@st.cache_data
def topologia_actual(firma=SHA_MODELO):
    return extraer_topologia()


def clave_linea(nombre):
    # EXT1 y EXT5 son a la vez nombres de nodo y de línea en el modelo.
    return 'linea:'+nombre


def nombre_elemento(clave):
    return 'Línea '+clave.split(':',1)[1] if clave.startswith('linea:') else clave


def estado_linea(l,tolerancia=1e-6):
    if 'flujo' not in l:return 'Sin solución'
    if l['capacidad']==0:return 'Sin capacidad disponible'
    if max(abs(l['inferior']),abs(l['superior']))==0:return 'Sin capacidad habilitada en esta hora'
    if abs(l['flujo'])>tolerancia and l['margen']<=tolerancia:return 'Capacidad alcanzada'
    if l['utilizacion'] is not None and l['utilizacion']>=UMBRAL_PROXIMIDAD:return 'Próxima a su capacidad'
    return 'Utilización normal'


def color_linea(l):
    return {'Capacidad alcanzada':'#B9363E','Próxima a su capacidad':'#A88A45',
            'Utilización normal':'#5D7E91'}.get(estado_linea(l),'#BBC8D0')


def titulo_linea(l):
    nombre=f"{l['id']}: {l['origen']} → {l['destino']}"
    if 'flujo' not in l:return nombre+' · sin resolución'
    sentido=f"{l['desde']} → {l['hasta']}" if l['signo'] else 'sin flujo apreciable'
    return (f"{nombre}. {sentido}; F={formato(l['flujo'],3)} MW; CAP={formato(l['capacidad'])} MW; "
            f"utilización nominal {formato(l['utilizacion'])} %; {estado_linea(l)}; permitido [{formato(l['inferior'])}, {formato(l['superior'])}] MW.")


def dimensiones(n):
    return (170,84) if n['tipo'] in ('Térmica','Hidráulica reversible','Nuclear') else (180,84) if n['tipo']=='Mercado exterior' else (160,84)


def extremos_linea(l,nodos):
    x,y=POSICIONES[l['origen']];xx,yy=POSICIONES[l['destino']];dx,dy=xx-x,yy-y
    def fraccion(c):
        w,h=dimensiones(nodos[c]);return min((w/2+10)/abs(dx) if dx else float('inf'),(h/2+10)/abs(dy) if dy else float('inf'))
    inicio=fraccion(l['origen']);fin=fraccion(l['destino'])
    return x+dx*inicio,y+dy*inicio,xx-dx*fin,yy-dy*fin


def extremos_trazo(extremos,signo):
    """El trazo acaba en la base; el marcador completa el recorrido hasta la punta."""
    x,y,xx,yy=extremos
    if not signo:return extremos
    longitud=hypot(xx-x,yy-y)
    ux,uy=(xx-x)/longitud,(yy-y)/longitud
    if signo>0:return x,y,xx-ux*TAMANO_FLECHA,yy-uy*TAMANO_FLECHA
    return x+ux*TAMANO_FLECHA,y+uy*TAMANO_FLECHA,xx,yy


def proporcion_produccion(n):
    """Magnitudes originales; únicamente la fracción del dibujo se acota a [0,1]."""
    if 'produccion' not in n or 'nominal' not in n:
        return None
    porcentaje=100*n['produccion']/n['nominal'] if n['nominal']>0 else None
    fraccion=(min(1.,max(0.,porcentaje/100))
              if porcentaje is not None and abs(n['produccion'])>TOL_FLUJO else 0.)
    return {'porcentaje':porcentaje,'fraccion':fraccion}


def textura_linea(l,extremos):
    """Degradado opaco en todo el trazo; se traslada una longitud por ciclo.

    Las conexiones actuales son segmentos rectos. El degradado colorea el mismo
    recorrido SVG que la línea, alineado con sus extremos; no añade objetos móviles.
    """
    flujo=l.get('flujo',0)
    if abs(flujo)<=TOL_FLUJO:
        return ''
    x1,y1,x2,y2=extremos
    dx,dy=x2-x1,y2-y1
    if hypot(dx,dy)==0:return ''
    signo=1 if flujo>0 else -1
    duracion=5.5-2.5*abs(flujo)/(abs(flujo)+500)
    color=color_linea(l)
    # Luz ancha y suave, nunca transparente: la banda conserva toda su continuidad.
    rgb=[int(color[k:k+2],16) for k in (1,3,5)]
    claro='#'+''.join(f'{round(v+(255-v)*.70):02X}' for v in rgb)
    oscuro='#'+''.join(f'{round(v*.65):02X}' for v in rgb)
    # Una zona clara ancha y extremos oscuros hacen visible la corriente, sin
    # convertirla en puntos o destellos ni interrumpir el color de fondo.
    paradas=[(0,oscuro),(.18,color),(.40,claro),(.60,claro),(.82,color),(1,oscuro)]
    return (f'<defs><linearGradient id="corriente-{escape(l["id"])}" class="textura-corriente" '
            f'data-dx="{signo*dx}" data-dy="{signo*dy}" data-duracion="{duracion}" gradientUnits="userSpaceOnUse" '
            f'x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" spreadMethod="repeat">'
            +''.join(f'<stop offset="{posicion}" stop-color="{tono}" stop-opacity="1"/>' for posicion,tono in paradas)
            +'</linearGradient></defs>')


def dibujar_svg(vista, seleccionado):
    nodos={n['id']:n for n in vista['nodos']}
    partes=['<svg xmlns="http://www.w3.org/2000/svg" style="font-family:Arial,sans-serif" viewBox="0 0 1280 750" role="group" aria-label="Red eléctrica seleccionable" data-solucion="'+('si' if 'indicadores' in vista else 'no')+'">',
            f'<rect width="1280" height="750" fill="#FBFCFD"/><defs><marker id="flecha" viewBox="0 0 10 10" refX="0" refY="5" markerWidth="{TAMANO_FLECHA}" markerHeight="{TAMANO_FLECHA}" markerUnits="userSpaceOnUse" orient="auto-start-reverse" overflow="visible"><path d="M0 0 L10 5 L0 10 Z" fill="#35586E" fill-opacity="1" stroke="#213F53" stroke-width="0.7" stroke-linejoin="round"/></marker></defs>']
    for l in vista['lineas']:
        x1,y1,x2,y2=extremos_linea(l,nodos);signo=l.get('signo',0);seleccion=clave_linea(l['id'])==seleccionado
        path=f'M{x1},{y1} L{x2},{y2}'
        a,b,c,d=extremos_trazo((x1,y1,x2,y2),signo)
        trazo_visible=f'M{a},{b} L{c},{d}'
        titulo=escape(titulo_linea(l));nombre=escape(l['id'])
        partes.append(f'<g role="button" tabindex="0" aria-label="{titulo}" data-elemento="{clave_linea(l["id"])}"><title>{titulo}</title>')
        if seleccion:partes.append(f'<path d="{trazo_visible}" stroke="#BCD9EB" stroke-width="14" stroke-linecap="butt" fill="none"/>')
        flecha='marker-end="url(#flecha)"' if signo>0 else 'marker-start="url(#flecha)"' if signo<0 else ''
        textura=textura_linea(l,(x1,y1,x2,y2));partes.append(textura)
        trazo=f'url(#corriente-{nombre})' if textura else color_linea(l)
        atributos=f'data-corriente="{nombre}" style="--color-linea:{color_linea(l)}"' if textura else ''
        ancho=4+min(100,l.get('utilizacion') or 0)/50 if textura else 2+min(100,l.get('utilizacion') or 0)/35
        partes.append(f'<path class="forma" d="{trazo_visible}" stroke="{trazo}" stroke-width="{ancho}" stroke-linecap="butt" fill="none" {flecha} {atributos} '+('stroke-dasharray="5 5"' if not signo else '')+'/>')
        partes.append(f'<path d="{path}" stroke="transparent" stroke-width="22" fill="none"/>')
        dx,dy=x2-x1,y2-y1;longitud=(dx*dx+dy*dy)**.5
        # Separar el fondo de las etiquetas de la banda, también en diagonales.
        tx,ty=(x1+x2)/2-dy/longitud*28,(y1+y2)/2+dx/longitud*28
        if l['id']=='A4':ty-=45
        elif l['id']=='D4':tx+=6;ty-=4
        elif l['id']=='EXT1':tx,ty=240,75
        elif l['id']=='EXT5':tx,ty=260,650
        w=len(nombre)*9+16
        partes.append(f'<rect x="{tx-w/2}" y="{ty-14}" width="{w}" height="25" rx="5" fill="#FBFCFD"/>')
        partes.append(f'<text x="{tx}" y="{ty+4}" font-size="17" font-weight="600" text-anchor="middle" fill="#446075">{nombre}</text></g>')
    for n in vista['nodos']:
        c=n['id'];x,y=POSICIONES[c];w,h=dimensiones(n);fondo,color,tipo=ESTILOS_NODO[n['tipo']]
        titulo=escape(f'{c} · {"Hidroeléctrica" if c in ("B","E") else n["tipo"]}');izq=x-w/2;arriba=y-h/2
        proporcion=proporcion_produccion(n)
        descripcion=(f"{n['estado']}. Producción: {formato(n['produccion'],3)} MW. Potencia máxima nominal del escenario resuelto: {formato(n['nominal'],3)} MW. "
                     +('Sin capacidad.' if proporcion['porcentaje'] is None else f"Producción / potencia nominal: {formato(proporcion['porcentaje'],3)} %.") if proporcion else '')
        accesible=f' aria-describedby="produccion-{c}"' if proporcion else ''
        partes.append(f'<g role="button" tabindex="0" aria-label="{titulo}"{accesible} data-elemento="{c}"><title>{titulo}{". "+escape(descripcion) if proporcion else ""}</title>')
        if proporcion:partes.append(f'<desc id="produccion-{c}">{escape(descripcion)}</desc>')
        if c==seleccionado:partes.append(f'<rect x="{izq-5}" y="{arriba-5}" width="{w+10}" height="{h+10}" rx="13" fill="#DFEDF6" stroke="#4C89AD" stroke-width="2"/>')
        partes.append(f'<rect class="forma" x="{izq}" y="{arriba}" width="{w}" height="{h}" rx="9" fill="{"#FFFFFF" if proporcion else fondo}" stroke="{color}" stroke-width="1.5"/>')
        if proporcion:
            partes.append(f'<clipPath id="relleno-{c}"><rect x="0" y="0" width="{w}" height="{h}" rx="9"/></clipPath>')
            tono={'Térmica':'#C6DCEB','Hidráulica reversible':'#BFE5DB','Nuclear':'#DBD0EF'}[n['tipo']]
            partes.append(f'<g transform="translate({izq},{arriba})" clip-path="url(#relleno-{c})" aria-hidden="true"><rect class="relleno-central" data-central="{c}" data-fraccion="{proporcion["fraccion"]}" x="0" y="0" width="{w}" height="{h}" fill="{tono}" style="transform:scaleY({proporcion["fraccion"]})"/></g>')
            # Repetir el contorno por encima del recorte mantiene los bordes visibles.
            partes.append(f'<rect x="{izq}" y="{arriba}" width="{w}" height="{h}" rx="9" fill="none" stroke="{color}" stroke-width="1.5" pointer-events="none"/>')
            etiqueta='Sin capacidad' if proporcion['porcentaje'] is None else formato(proporcion['porcentaje'],1)+' %'
            partes.append(f'<text x="{izq+w-12}" y="{arriba+44}" font-size="12" font-weight="600" text-anchor="end" fill="#345367">{etiqueta}</text>')
        partes.append(f'<text x="{izq+12}" y="{arriba+18}" font-size="12" font-weight="600" letter-spacing=".25" fill="{color}">{tipo}</text>')
        partes.append(f'<text x="{izq+12}" y="{arriba+46}" font-size="24" font-weight="700" fill="#203D50">{c}</text>')
        if 'produccion' in n:nota=formato(n['produccion'],1)+' MW'
        elif 'demanda' in n:nota=formato(n['demanda'],1)+' MW'
        elif 'compra' in n:nota=('Compra ' if n['compra']>TOL_FLUJO else 'Venta ')+formato(n['compra'] if n['compra']>TOL_FLUJO else n['venta'],1)+' MW'
        else:nota='Sin solución'
        partes.append(f'<text x="{izq+12}" y="{arriba+h-12}" font-size="17" fill="#415E72">{escape(nota)}</text></g>')
    partes.append('</svg>');return ''.join(partes)


def observaciones(v):
    generando=[n['id'] for n in v['nodos'] if n.get('produccion',0)>TOL_FLUJO]
    bombeando=[n['id'] for n in v['nodos'] if n.get('bombeo',0)>TOL_FLUJO]
    textos=['Generan: '+(', '.join(generando) or 'ninguna central')+'. Bombeo: '+(', '.join(bombeando) or 'sin consumo apreciable')+'.']
    definidas=[l for l in v['lineas'] if l['utilizacion'] is not None]
    if definidas:
        mayor=max(definidas,key=lambda l:l['utilizacion'])
        textos.append(f"Mayor utilización: {mayor['id']}, {formato(mayor['utilizacion'])} %."+
                      (' '+estado_linea(mayor)+'.'+(' Umbral de proximidad: 95 %.' if estado_linea(mayor)=='Próxima a su capacidad' else '')))
    else:textos.append('No hay porcentajes de utilización definidos: todas las capacidades son cero.')
    textos.append(f"Margen de reserva: {formato(v['indicadores']['margen_reserva'])} MW sobre la reserva requerida.")
    return textos


def panel_html(v):
    if 'indicadores' not in v:return '<section class="red-panel"><h4>Sin solución representada</h4><p>El esquema muestra únicamente las conexiones del modelo. Optimiza un escenario para consultar flujos, estados e indicadores.</p></section>'
    k=v['indicadores'];etiquetas={'demanda':'Demanda','generacion':'Generación bruta','compra':'Compra exterior','venta':'Venta exterior',
        'bombeo':'Consumo de bombeo','reserva_total':'Reserva disponible','reserva_requerida':'Reserva requerida','margen_reserva':'Margen de reserva'}
    html='<section class="red-panel"><h4>'+escape(intervalo(v['hora']))+'</h4><div class="indicadores">'
    for clave,etiqueta in etiquetas.items():html+=f'<div class="indicador"><span>{etiqueta}</span><strong>{formato(k[clave])} <small>MW</small></strong></div>'
    izquierda=k['generacion']+k['compra'];derecha=k['demanda']+k['venta']+k['bombeo']
    ok=abs(v['balance'])<=v['tolerancia_balance']
    html+='</div><div class="balance"><p><b>Generación + compras = demanda + ventas + bombeo</b></p>'
    html+=f'<p>{formato(izquierda,3)} MW = {formato(derecha,3)} MW</p><p>{"Balance comprobado" if ok else "Revisar diferencia de balance"}. El detalle numérico está disponible debajo del esquema.</p></div>'
    return html+'<ul>'+''.join('<li>'+escape(t)+'</li>' for t in observaciones(v))+'</ul></section>'


def mostrar_detalle(v,elemento):
    n=next((n for n in v['nodos'] if n['id']==elemento),None)
    l=next((l for l in v['lineas'] if clave_linea(l['id'])==elemento),None)
    st.markdown('#### Detalle · '+(f"Línea {l['id']}" if l else elemento))
    if 'indicadores' not in v:
        st.info(n['tipo'] if n else f"Línea {l['origen']} → {l['destino']}. Sin datos de una resolución.")
        return
    st.caption(intervalo(v['hora']))
    if l:
        st.write(titulo_linea(l))
        st.write(f"Margen en el sentido del flujo: **{formato(l['margen'])} MW**. Rango admisible con el estado de esta hora: [{formato(l['inferior'])}, {formato(l['superior'])}] MW.")
        st.caption('Utilización nominal = |F| / CAP. Hay una única variable de flujo por línea y hora. En hidráulicas, el rango admisible depende de las variables de generación y bombeo; ambas deshabilitadas implican flujo cero.')
        if l['capacidad']==0:st.info('Capacidad cero: utilización no aplicable. El límite de flujo es cero.')
        if abs(l['flujo'])<=TOL_FLUJO:st.caption(f"Sin flecha por |F| ≤ {TOL_FLUJO:g} MW. Valor sin redondear: {l['flujo']!r} MW.")
    elif 'produccion' in n:
        st.write(f"**{n['tipo']} · {n['estado']}**. Producción: **{formato(n['produccion'])} MW**.")
        st.write(f"Límites de producción en este estado: {formato(n['minimo'])}–{formato(n['maximo'])} MW. Potencia nominal: {formato(n['nominal'])} MW.")
        st.caption(f"Variable de encendido/generación: {formato(n['encendida'],6)}; arranque: {formato(n['arranque'],6)}. El estado procede de las variables binarias, no de inferirlo a partir de la producción.")
        if 'maximo_sos2' in n:st.caption(f"Límite superior adicional de la curva SOS2 y la potencia máxima: {formato(n['maximo_sos2'])} MW.")
        if 'bombeo' in n:
            st.write(f"Bombeo: **{formato(n['bombeo'])} MW**; máximo habilitado MB·alphaBH: {formato(n['max_bombeo'])} MW. Variable de bombeo habilitado: {formato(n['bombeo_habilitado'],6)}.")
            st.write(f"Nivel **al final de la hora**: **{formato(n['nivel'],3)} m**, entre {formato(n['nivel_min'])} y {formato(n['nivel_max'])} m. Nivel inicial del día: {formato(n['nivel_inicial'])} m.")
            st.caption('La red puede limitar adicionalmente el consumo de bombeo. No se exige recuperar el nivel inicial al finalizar el día.')
    elif n['tipo']=='Centro de transformación':
        st.write(f"Demanda: **{formato(n['demanda'])} MW**. Suma de flujos incidentes: **{formato(n['entrada'])} MW**. Residuo: {n['residual']:.3e} MW.")
        if 'compra' in n:st.write(f"Compra: {formato(n['compra'])} MW; venta: {formato(n['venta'])} MW. Ya están incluidas a través de la línea exterior; no se suman dos veces al balance.")
    else:
        st.write(f"Conexión con CT{n['centro']}. Compra: **{formato(n['compra'])} MW**; venta: **{formato(n['venta'])} MW**.")
        st.caption(f"Compra habilitada: {formato(n['compra_habilitada'],6)}; venta habilitada: {formato(n['venta_habilitada'],6)}. No son simultáneas en esta conexión.")
    incidentes=[l] if l else [a for a in v['lineas'] if elemento in (a['origen'],a['destino'])]
    detalle=tabla_lineas(incidentes)
    tabla('detalle_red_horaria',detalle)


def tabla_lineas(lineas):
    return pd.DataFrame([{'Línea':a['id'],'Origen positivo':a['origen'],'Destino positivo':a['destino'],
         'F firmado (MW)':a['flujo'],'Sentido':f"{a['desde']} → {a['hasta']}" if a['signo'] else '≈ 0',
         'CAP (MW)':a['capacidad'],'Mínimo permitido (MW)':a['inferior'],'Máximo permitido (MW)':a['superior'],
         'Estado de capacidad':estado_linea(a),'Utilización nominal (%)':a['utilizacion'],'Margen en el sentido (MW)':a['margen']} for a in lineas])

def detalle_html(v,elemento):
    n=next((n for n in v['nodos'] if n['id']==elemento),None)
    l=next((l for l in v['lineas'] if clave_linea(l['id'])==elemento),None)
    titulo=escape(nombre_elemento(elemento))
    if 'indicadores' not in v:return '<section class="red-detalle"><h4>Seleccionado · '+titulo+'</h4><p>Topología sin datos de una solución.</p></section>'
    if l:descripcion=titulo_linea(l)+' Margen: '+formato(l['margen'])+' MW.'
    elif 'produccion' in n:
        descripcion=('Hidroeléctrica' if n['id'] in ('B','E') else n['tipo'])+' · '+n['estado']+'. Producción: '+formato(n['produccion'])+' MW. Límites habilitados: '+formato(n['minimo'])+'–'+formato(n['maximo'])+' MW.'
        if 'bombeo' in n:descripcion+=' Bombeo: '+formato(n['bombeo'])+' MW (máximo habilitado '+formato(n['max_bombeo'])+' MW). Nivel al final de la hora: '+formato(n['nivel'],3)+' m; límites '+formato(n['nivel_min'])+'–'+formato(n['nivel_max'])+' m.'
        if 'maximo_sos2' in n:descripcion+=' Máximo adicionalmente limitado por SOS2: '+formato(n['maximo_sos2'])+' MW.'
    elif 'demanda' in n:descripcion='Demanda: '+formato(n['demanda'])+' MW. Flujos incidentes netos: '+formato(n['entrada'])+' MW.'
    else:descripcion='Mercado exterior · compra '+formato(n['compra'])+' MW; venta '+formato(n['venta'])+' MW.'
    ls=[l] if l else [a for a in v['lineas'] if elemento in (a['origen'],a['destino'])]
    filas=''.join('<tr><td>'+escape(a['id'])+'</td><td>'+escape((a['desde']+' → '+a['hasta']) if a['signo'] else 'Sin flujo apreciable')+'</td><td>'+formato(a['flujo'],3)+'</td><td>'+formato(a['capacidad'])+'</td><td>'+escape(estado_linea(a))+'</td></tr>' for a in ls)
    return '<section class="red-detalle"><h4>Seleccionado · '+titulo+'</h4><p>'+escape(descripcion)+'</p><div style="overflow:auto"><table><thead><tr><th>Línea</th><th>Sentido</th><th>F (MW)</th><th>CAP (MW)</th><th>Estado</th></tr></thead><tbody>'+filas+'</tbody></table></div></section>'


def mostrar_red(ejecucion,datos):
    topo=topologia_actual()
    valida=bool(ejecucion and es_optimo({'parametros':ejecucion.get('parametros'), 'ejecucion':ejecucion}))
    st.markdown('#### Red y operación por hora')
    if valida:
        st.caption(f"Escenario resuelto: {ejecucion.get('escenario','Escenario guardado')} · ejecución: {fecha_legible(ejecucion['fecha'])} · {version_ejecucion(ejecucion)}")
        if desactualizado(ejecucion,datos):st.warning('Solución anterior: los parámetros editables han cambiado. Esta red utiliza exclusivamente los parámetros y resultados de la ejecución indicada, no los datos que estás editando. Optimiza de nuevo para actualizarla.')
        else:st.success('Solución óptima vigente · datos de la ejecución indicada.')
    else:
        st.warning('Sin solución óptima válida de la versión actual. Se muestra únicamente la topología. Recupera un escenario vigente o pulsa Optimizar.')
        if ejecucion:st.caption(f"Última ejecución: {fecha_legible(ejecucion.get('fecha',''))} · {version_ejecucion(ejecucion)} · {ejecucion.get('estado','')}")
    if st.session_state.get('hora_red') not in topo['horas']:st.session_state['hora_red']=topo['horas'][0]
    def fijar_hora():st.session_state['hora_red']=st.session_state['_hora_red']
    def paso(delta):st.session_state['hora_red']+=delta
    st.session_state['_hora_red']=st.session_state['hora_red']
    with st.expander('Seleccionar periodo · alternativa accesible',expanded=False):
        izquierda,centro,derecha=st.columns([1,3,1])
        with izquierda:st.button('← Anterior',key='red_anterior',disabled=st.session_state['hora_red']==0,on_click=paso,args=(-1,),width='stretch')
        with centro:st.select_slider('Periodo de la solución',options=topo['horas'],format_func=intervalo,key='_hora_red',on_change=fijar_hora)
        with derecha:st.button('Siguiente →',key='red_siguiente',disabled=st.session_state['hora_red']==23,on_click=paso,args=(1,),width='stretch')
    hora=st.session_state['hora_red'];vista=preparar_hora(ejecucion,hora,topo) if valida else topo
    ids=[n['id'] for n in topo['nodos']]+[clave_linea(l['id']) for l in topo['lineas']]
    if st.session_state.get('elemento_red') not in ids:st.session_state['elemento_red']='A'
    def seleccion_directa():
        seleccionado=st.session_state.get('esquema_red',{}).get('seleccion')
        if seleccionado in ids:st.session_state['elemento_red']=seleccionado
    svg=dibujar_svg(vista,st.session_state['elemento_red'])
    def hora_directa():
        elegida=st.session_state.get('esquema_red',{}).get('hora')
        if isinstance(elegida,(int,float)) and int(elegida) in topo['horas']:st.session_state['hora_red']=int(elegida)
    opciones=''.join(f'<option value="{h}" '+('selected' if h==hora else '')+'>'+intervalo(h)+'</option>' for h in topo['horas'])
    toolbar=(
        '<div class="red-toolbar" role="toolbar" aria-label="Controles de la red">'
        '<section class="red-grupo red-grupo-vista" role="group" aria-label="Visualización y encuadre">'
        '<h5>Visualización y encuadre</h5><div class="red-acciones">'
        '<button class="primario ampliar">Ampliar red</button><button class="primario volver">Volver a vista normal</button>'
        '<button data-zoom="menos" aria-label="Reducir zoom">−</button><button data-zoom="mas" aria-label="Aumentar zoom">+</button>'
        '<button data-zoom="ajustar">Ajustar al área</button><button data-zoom="leer">Tamaño legible</button></div></section>'
        '<section class="red-grupo red-grupo-horas" role="group" aria-label="Selección y reproducción de horas">'
        '<h5>Selección y reproducción de horas</h5><div class="red-acciones"><span class="controles-hora">'
        '<button data-hora="-1" aria-label="Hora anterior">←</button><select class="hora-ampliada" aria-label="Hora de la red">'+opciones+'</select>'
        '<button data-hora="1" aria-label="Hora siguiente">→</button></span>'
        '<button class="reproduccion" title="Recorre las horas de la solución sin resolver el modelo">Reproducir horas</button>'
        '<select class="velocidad-horas" aria-label="Velocidad de reproducción"><option value="1000">1 s / hora</option><option value="2000">2 s / hora</option><option value="4000">4 s / hora</option></select></div></section>'
        '<section class="red-grupo red-grupo-textura" role="group" aria-label="Movimiento de la textura">'
        '<h5>Movimiento de la textura</h5><button class="movimiento" aria-pressed="false">Textura</button>'
        '<p>Solo la corriente de las líneas; mantiene la hora.</p></section></div>')

    leyenda='<div class="leyenda"><span>Térmicas: A, C, F</span><span>Hidroeléctricas: B, E</span><span>Nuclear: D</span><span>CT: demanda</span><span>EXT: mercado</span><span>Líneas: azul · normal / ocre · próxima / rojo · capacidad alcanzada</span></div>'
    leyenda+='<p class="red-ayuda">Pulsa una tarjeta o una etiqueta de línea. Flechas: sentido real. Proximidad: ≥ 95 %. Sin capacidad habilitada: trazo gris. Las capacidades y estados completos están en el detalle.</p>'
    leyenda+=f'<p class="red-ayuda">Relleno de las centrales: producción / potencia máxima nominal del escenario resuelto. En B y E representa generación, no agua almacenada. Corriente continua: textura en el sentido del flujo; líneas estáticas si |F| ≤ {TOL_FLUJO:g} MW. La pausa conserva el relleno, las flechas y los valores.</p>'
    cabecera='<div class="red-cabecera"><b>OPERACIÓN DE LA RED</b><span>'+escape(intervalo(hora))+' · Selección: '+escape(nombre_elemento(st.session_state['elemento_red']))+'</span></div>'
    aviso='<p class="red-ayuda">Escritorio: encuadre completo. En ventanas estrechas, amplía o desplaza el esquema. «Reproducir horas» recorre el día y se detiene al final; «Pausar movimiento» solo congela la textura.</p><p class="red-aviso" role="status"></p>'
    identidad='<p class="solo-ampliada red-ayuda">'+escape(ejecucion.get('escenario','Escenario')+' · '+fecha_legible(ejecucion['fecha']) if valida else 'Sin solución óptima válida')+(' · Solución anterior: parámetros editables modificados' if valida and desactualizado(ejecucion,datos) else '')+'</p>'
    html=toolbar+identidad+'<div class="red-layout"><section class="red-dibujo">'+cabecera+aviso+'<div class="red-lienzo" tabindex="0" aria-label="Esquema desplazable horizontalmente">'+svg+'</div>'+leyenda+'</section>'+panel_html(vista)+detalle_html(vista,st.session_state['elemento_red'])+'</div>'
    ESQUEMA(data={'html':html,'hora':hora,'css':CSS,'defensa':st.session_state.get('modo_defensa',False),'firma':(ejecucion.get('fecha','')+ejecucion.get('huella','')) if valida else 'sin_solucion'},key='esquema_red',on_seleccion_change=seleccion_directa,on_hora_change=hora_directa)
    st.session_state['_elemento_red']=st.session_state['elemento_red']
    def seleccion_lista():st.session_state['elemento_red']=st.session_state['_elemento_red']
    acceso=st.expander('Seleccionar elemento · alternativa accesible') if st.session_state.get('modo_defensa') else st.container()
    with acceso:
        st.selectbox('Elemento seleccionado · alternativa accesible',ids,format_func=nombre_elemento,key='_elemento_red',on_change=seleccion_lista)
    with st.expander('Detalle completo del elemento · variables y límites'):
        mostrar_detalle(vista,st.session_state['elemento_red'])
    if valida:
        with st.expander('Comprobación numérica y versión de la solución'):
            st.write(f"Residuo global: {vista['balance']:.6g} MW; tolerancia: {vista['tolerancia_balance']:.6g} MW.")
            st.caption('Versión: '+version_ejecucion(ejecucion)+' · '+ejecucion['sha_modelo'])
    if valida:
        r=ejecucion['resultados']
        with st.expander('Todas las líneas de la hora seleccionada · sentidos, límites y utilización'):
            tabla('lineas_hora_seleccionada',tabla_lineas(vista['lineas']))
        with st.expander('Reserva · gráfico y tabla de las 24 horas'):
            grafico_lineas(r['horas'],{'reserva_total':'Disponible','reserva_requerida':'Requerida'},'MW','reserva',{'Disponible':'#24748D','Requerida':'#B16625'})
            st.caption('Reserva conforme a App.py; no se simula su activación ni su transporte por la red.')
            tabla('reservas',r['tablas']['reservas'])
        with st.expander('Flujos por las líneas · 24 horas'):tabla('flujos',r['tablas']['flujos'])
        with st.expander('Utilización de líneas · 24 horas'):tabla('utilizacion_lineas',r['tablas']['utilizacion_lineas'])
