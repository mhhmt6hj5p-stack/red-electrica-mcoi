"""Escenarios locales: instantáneas independientes en JSON, sin base de datos."""
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import json
import math
import os
import tempfile
import uuid
import pandas as pd
from datos import META, huella, validar
from version_modelo import (VERSION_MODELO, VERSION_ANTERIOR, SHA_ANTERIOR,
                            ORIGINAL_ID, ejecucion_vigente, version_ejecucion)

CARPETA = Path(os.environ.get('MCOI_ESCENARIOS_DIR', Path(__file__).parent / 'escenarios'))
INDICES_ENTEROS = {'DM', 'd', 'PEX', 'PREC', 'PC', 'PV'}


def normalizar_parametros(datos):
    return {p: ({(int(k) if p in INDICES_ENTEROS else k): v for k, v in vals.items()}
                if isinstance(vals, dict) else vals) for p, vals in datos.items()}


def a_json(obj):
    if isinstance(obj, pd.DataFrame):
        return {'__tabla__': True, 'columnas': list(obj.columns),
                'filas': a_json(obj.to_numpy(dtype=object).tolist())}
    if isinstance(obj, dict):
        return {k: a_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [a_json(v) for v in obj]
    if isinstance(obj, float) and not math.isfinite(obj):
        return None
    return obj


def desde_json(obj):
    if isinstance(obj, dict):
        if obj.get('__tabla__') is True:
            return pd.DataFrame(obj['filas'], columns=obj['columnas'])
        return {k: (normalizar_parametros(v) if k in ('parametros', 'datos') else desde_json(v))
                for k, v in obj.items()}
    if isinstance(obj, list):
        return [desde_json(v) for v in obj]
    return obj


def escribir_json(ruta, obj):
    raise RuntimeError('La biblioteca pública es de solo lectura.')


def es_optimo(escenario, exigir_vigente=True):
    e = escenario.get('ejecucion')
    if not e or e.get('estado') != 'optimal' or e.get('terminacion') != 'optimal':
        return False
    if exigir_vigente and not ejecucion_vigente(e):
        return False
    r = e.get('resultados')
    return bool(r and r.get('verificacion', {}).get('valida')
                and e.get('parametros') == escenario['parametros']
                and e.get('huella') == huella(e['parametros'])
                and huella(r['datos']) == e['huella'])


def estado_escenario(s):
    if es_optimo(s):
        return 'Óptimo · ' + VERSION_MODELO
    if es_optimo(s, exigir_vigente=False):
        return 'Histórico · óptimo · ' + version_ejecucion(s['ejecucion'])
    e = s.get('ejecucion')
    if not e:
        return 'Pendiente de resolución'
    return {'infeasible': 'Infactible', 'sin_optimalidad': 'Sin optimalidad',
            'unbounded': 'No acotado', 'indeterminado': 'Diagnóstico indeterminado',
            'error': 'Error', 'error_validacion': 'Error de validación'}.get(e['estado'], 'Sin solución óptima')


def leer_escenarios(carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    registros, avisos = [], []
    for ruta in sorted(carpeta.glob('*.json')):
        if ruta.name.startswith('_'):
            continue
        try:
            s = desde_json(json.loads(ruta.read_text(encoding='utf-8')))
            if s['version'] != 1 or s['huella'] != huella(s['parametros']):
                raise ValueError('versión o huella no válida')
            if s.get('ejecucion'):
                e = s['ejecucion']
                if e['huella'] != s['huella'] or huella(e['parametros']) != s['huella']:
                    raise ValueError('los parámetros no corresponden a la ejecución')
                if e['estado'] == 'optimal' and not es_optimo(s, exigir_vigente=False):
                    raise ValueError('resultado óptimo inconsistente')
                if e['estado'] != 'optimal' and e.get('resultados') is not None:
                    raise ValueError('resultados asociados a una ejecución no óptima')
            if s.get('ejecucion'):
                s['ejecucion'].setdefault('version_modelo', VERSION_ANTERIOR)
                s['ejecucion'].setdefault('sha_modelo', SHA_ANTERIOR)
            registros.append(s)
        except (ValueError, KeyError, TypeError, OSError) as exc:
            avisos.append(f'No se pudo cargar {ruta.name}: {exc}. El archivo se conserva.')
    return sorted(registros, key=lambda s: (s['id'] != ORIGINAL_ID, s['creado'])), avisos


def adjuntar_ejecucion(datos, ejecucion):
    if not ejecucion or not ejecucion_vigente(ejecucion) or ejecucion.get('huella') != huella(datos):
        return None
    e = deepcopy(ejecucion)
    if huella(e['parametros']) != huella(datos):
        raise ValueError('La ejecución contiene parámetros diferentes.')
    if e['estado'] == 'optimal':
        if not es_optimo({'parametros': datos, 'ejecucion': e}):
            raise ValueError('Los resultados no pertenecen a los parámetros guardados.')
    else:
        e['resultados'] = None
    return e


def nuevo_registro(nombre, descripcion, datos, ejecucion, identificador):
    # Si solo cambia la representación int/float, conservar la instantánea exacta
    # de la ejecución. No reescribir sus datos ni alterar las huellas históricas.
    if ejecucion_vigente(ejecucion) and ejecucion.get('parametros') == datos:
        datos = ejecucion['parametros']
    return {'version': 1, 'id': identificador, 'nombre': nombre, 'descripcion': descripcion,
            'creado': datetime.now(ZoneInfo('Europe/Madrid')).isoformat(timespec='seconds'),
            'parametros': deepcopy(datos), 'huella': huella(datos),
            'ejecucion': adjuntar_ejecucion(datos, ejecucion)}


def asegurar_original(datos, ejecucion=None, carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    ruta = carpeta / f'{ORIGINAL_ID}.json'
    if ruta.exists():
        registros, _ = leer_escenarios(carpeta)
        existente = next((s for s in registros if s['id'] == ORIGINAL_ID), None)
        if not existente or existente['parametros'] != datos:
            raise ValueError('El archivo Caso original no coincide con App.py. Se ha conservado para revisión.')
        if es_optimo(existente) or not ejecucion:
            return existente
    s = nuevo_registro('Caso original', 'Valores originales de App.py para la formulación ' + VERSION_MODELO + '.',
                       datos, ejecucion, ORIGINAL_ID)
    escribir_json(ruta, s)
    return s


def guardar_escenario(nombre, descripcion, datos, ejecucion, originales, carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    errores, _ = validar(datos, originales)
    if errores:
        raise ValueError('No se puede guardar: ' + '; '.join(errores))
    nombre = nombre.strip()
    if not nombre:
        raise ValueError('Escribe un nombre para el escenario.')
    if nombre.casefold() == 'caso original':
        raise ValueError('Caso original está reservado. Elige un nombre para tu experimento.')
    registros, _ = leer_escenarios(carpeta)
    nombres = {s['nombre'].casefold() for s in registros}
    base, numero = nombre, 2
    while nombre.casefold() in nombres:
        nombre = f'{base} ({numero})'
        numero += 1
    s = nuevo_registro(nombre, descripcion.strip(), datos, ejecucion, uuid.uuid4().hex)
    escribir_json(carpeta / f'{s["id"]}.json', s)
    return s


def duplicar_escenario(s, originales, carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    return guardar_escenario(s['nombre'] + ' · copia', s['descripcion'], s['parametros'],
                            s.get('ejecucion'), originales, carpeta)


def guardar_referencia(identificador, carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    registros, _ = leer_escenarios(carpeta)
    if not any(s['id'] == identificador for s in registros):
        raise ValueError('La referencia seleccionada ya no existe.')
    escribir_json(carpeta / '_preferencias.json', {'referencia': identificador})


def leer_referencia(carpeta=None):
    carpeta = CARPETA if carpeta is None else Path(carpeta)
    try:
        return json.loads((carpeta/'_preferencias.json').read_text())['referencia']
    except (OSError, ValueError, KeyError):
        return ORIGINAL_ID


def comparar(referencia, escenarios):
    if not es_optimo(referencia) or any(not es_optimo(s) for s in escenarios):
        raise ValueError('Solo se comparan escenarios con resultados óptimos asociados a sus parámetros.')
    base = referencia['ejecucion']['resultados']['coste_total']
    filas = []
    for s in escenarios:
        r = s['ejecucion']['resultados']
        h = r['horas']
        diferencia = r['coste_total'] - base
        filas.append({'Escenario': s['nombre'], 'Versión del modelo': version_ejecucion(s['ejecucion']), 'Coste neto (€)': r['coste_total'],
                      'Diferencia (€)': diferencia,
                      'Diferencia (%)': diferencia / abs(base) * 100 if base != 0 else None,
                      'Cambio de coste': ('Reducción' if diferencia < -0.005 else 'Aumento' if diferencia > 0.005 else 'Sin cambio a céntimos'),
                      'Demanda (MWh)': r['demanda_MWh'], 'Producción total (MWh)': r['generacion_MWh'],
                      **{f'Producción {c} (MWh)': float(h[c].sum()) for c in 'ABCDEF'},
                      'Compra (MWh)': float(h['compra'].sum()), 'Venta (MWh)': float(h['venta'].sum()),
                      'Bombeo (MWh)': float(h['bombeo'].sum()), 'Menor margen de reserva (MW)': r['margen_reserva_minimo']})
    return pd.DataFrame(filas)


def cambios_parametros(referencia, escenarios):
    filas = []
    for s in escenarios:
        for p, antes in referencia['parametros'].items():
            despues = s['parametros'][p]
            pares = [(k, v, despues[k]) for k,v in antes.items()] if isinstance(antes, dict) else [('', antes, despues)]
            for k, a, b in pares:
                if a != b:
                    etiqueta, unidad, _, _, _, factor = META[p]
                    filas.append({'Escenario': s['nombre'], 'Parámetro': etiqueta, 'Símbolo': p,
                                  'Índice': str(k), 'Unidad': unidad, 'Referencia': a*factor,
                                  'Escenario comparado': b*factor, 'Diferencia': (b-a)*factor})
    return pd.DataFrame(filas, columns=['Escenario','Parámetro','Símbolo','Índice','Unidad','Referencia','Escenario comparado','Diferencia'])
