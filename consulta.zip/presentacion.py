"""Presentación: tarjetas adaptables, formato español y gráficos con colores estables."""
from decimal import Decimal
from datetime import datetime
from zoneinfo import ZoneInfo
from html import escape
import math
import re
import altair as alt
import pandas as pd
import streamlit as st
from resultados import csv_bytes

COLORES = {'A':'#24748D','B':'#276B48','C':'#B16625','D':'#7761A8','E':'#4C9184','F':'#B44E60'}
PALETA = {**COLORES, 'Demanda':'#162B42', 'Generación bruta':'#24748D',
          'Aporte neto':'#B16625', 'Compra':'#24748D', 'Venta':'#B16625',
          'Embalse B':COLORES['B'], 'Embalse E':COLORES['E']}


def estilo():
    st.markdown('''<style>
    /* La barra fija mide 60 px. El contenido comienza debajo, también en móvil. */
    .block-container {padding-top:calc(60px + .75rem); padding-bottom:2rem; max-width:1500px;}
    /* Identidad de la portada: todos los estilos quedan dentro de esta zona. */
    .st-key-mcoi_portada {position:relative;container-type:inline-size;isolation:isolate;gap:0;
        padding:22px 28px;border:1px solid #D1E2E5;border-radius:18px;
        background:linear-gradient(115deg,#EAF5F2 0%,#F4F8FA 54%,#EBF1F9 100%);
        margin-bottom:2px;}
    .st-key-mcoi_portada::before {content:"";position:absolute;inset:0;z-index:-1;border-radius:inherit;pointer-events:none;
        background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='500' height='230' viewBox='0 0 500 230'%3E%3Cg fill='none' stroke='%237AA7B0' stroke-width='1.2' opacity='.18'%3E%3Cpath d='M25 230L130 130H270L365 35H500M130 130L215 215H415L500 130M270 130L365 225M365 35L445 115H500'/%3E%3C/g%3E%3Cg fill='%23578F9A' opacity='.16'%3E%3Ccircle cx='130' cy='130' r='4'/%3E%3Ccircle cx='270' cy='130' r='4'/%3E%3Ccircle cx='365' cy='35' r='4'/%3E%3Ccircle cx='215' cy='215' r='4'/%3E%3Ccircle cx='415' cy='215' r='4'/%3E%3Ccircle cx='445' cy='115' r='4'/%3E%3C/g%3E%3C/svg%3E");
        background-repeat:no-repeat;background-position:right center;background-size:auto 100%;}
    /* Streamlit compensa el margen de sus párrafos con -1rem. Aquí los márgenes
       ya son propios: retirar esa compensación evita solapamientos en la portada. */
    .st-key-mcoi_portada [data-testid="stMarkdownContainer"],
    .st-key-mcoi_portada [data-testid="stCaptionContainer"] {margin-bottom:0;}
    .st-key-mcoi_portada .mcoi-cabecera {min-width:0;}
    .st-key-mcoi_portada .mcoi-identidad {display:flex;align-items:center;gap:11px;min-height:32px;padding-right:110px;}
    .st-key-mcoi_portada .mcoi-simbolo {flex:0 0 32px;width:32px;height:32px;}
    .st-key-mcoi_portada .mcoi-firma {display:flex;align-items:center;gap:10px;flex-wrap:wrap;line-height:1.5;}
    .st-key-mcoi_portada .mcoi-codigo {font-size:14px;font-weight:750;letter-spacing:.12em;color:#205C65;}
    .st-key-mcoi_portada .mcoi-separador {color:#7B9C9E;}
    .st-key-mcoi_portada .mcoi-descriptor {font-size:10px;letter-spacing:.14em;font-weight:650;color:#4B6977;}
    .st-key-mcoi_portada .mcoi-cabecera h1 {font-family:'Avenir Next','Segoe UI',sans-serif;
        font-size:clamp(2.4rem,4.6cqi,3.5rem);font-weight:700;line-height:1.12;
        margin:10px 0 9px;padding:0;letter-spacing:-.05em;color:#163B50;overflow-wrap:normal;}
    .st-key-mcoi_portada .mcoi-titulo-acento {color:#24776F;}
    .st-key-mcoi_portada .mcoi-cabecera p {margin:0;max-width:540px;line-height:1.55;color:#4B6577;font-size:.93rem;}
    .st-key-mcoi_modo {position:absolute;top:15px;right:18px;width:auto !important;gap:0;}
    .st-key-mcoi_modo [data-testid="stPopoverButton"] {color:#5A7280;min-height:34px;padding:5px 7px;}
    .st-key-mcoi_modo [data-testid="stPopoverButton"] p {font-size:11px;}
    .st-key-pestana_principal [role="tablist"] {gap:20px;border-bottom:1px solid #D9E4E9;}
    .st-key-pestana_principal [role="tab"] {padding-top:10px;padding-bottom:11px;}
    @container(max-width:650px) {
        .st-key-mcoi_portada .mcoi-cabecera h1 {font-size:clamp(2.15rem,8cqi,2.8rem);}
        .st-key-mcoi_portada .mcoi-descriptor {font-size:9px;letter-spacing:.1em;}
        .st-key-mcoi_modo {right:12px;top:15px;}
    }
    [data-testid="stAppDeployButton"] {display:none;}
    button:focus-visible,summary:focus-visible {outline:3px solid #24748D;outline-offset:3px;}
    [data-testid="stButtonGroup"] button {border-radius:8px;min-height:40px;}
    [data-testid="stDataFrame"] {border:1px solid #D8E3E8;border-radius:10px;}
    h2,h3,h4 {letter-spacing:-.015em;}
    .mcoi-grid {display:grid; grid-template-columns:repeat(auto-fit,minmax(min(100%,220px),1fr)); gap:16px; margin:16px 0 24px;}
    .mcoi-card {min-width:0; padding:20px; border:1px solid #D8E3E8; border-radius:14px; background:#fff; box-shadow:0 2px 6px #19394A05;}
    .mcoi-grid-compacto {grid-template-columns:repeat(auto-fit,minmax(min(100%,180px),1fr));}
    .mcoi-grid-compacto .mcoi-card {padding:16px;}
    .mcoi-grid-compacto .mcoi-value {font-size:1.7rem;}
    .mcoi-label {font-size:0.95rem; color:#415569; line-height:1.45; margin-bottom:10px; white-space:normal; overflow-wrap:anywhere;}
    .mcoi-value {font-size:clamp(1.6rem,3vw,2.2rem); font-weight:650; color:#162B42; line-height:1.25; overflow-wrap:anywhere; font-variant-numeric:tabular-nums;}
    .mcoi-unit {font-size:0.9rem; font-weight:400; color:#516779; display:block; margin-top:5px;}
    .mcoi-note {font-size:0.86rem; line-height:1.5; color:#516779; margin:12px 0 0; overflow-wrap:anywhere;}
    .mcoi-hero {background:#EDF5F4; border-color:#B8D5CF; margin:16px 0;}
    .mcoi-hero .mcoi-value {font-size:clamp(2rem,5vw,3.2rem); color:#205D59;}
    .mcoi-hero .mcoi-unit {display:inline-block; margin-left:12px; font-size:1.05rem;}
    [data-testid="stSidebar"] {background:#EEF3F6;}
    [data-testid="stSidebar"] h3 {font-size:1.1rem;}
    </style>''', unsafe_allow_html=True)


def formato(n, decimales=2):
    if n is None or pd.isna(n):
        return 'No aplicable'
    # Solo presentación: eliminar el signo si el número redondeado es cero.
    n = 0.0 if round(float(n), decimales) == 0 else n
    return f'{n:,.{decimales}f}'.translate(str.maketrans({',':'.','.':','}))


def fecha_legible(texto):
    try:
        fecha=datetime.fromisoformat(texto)
        if fecha.tzinfo:fecha=fecha.astimezone(ZoneInfo('Europe/Madrid'))
        meses=['ene','feb','mar','abr','may','jun','jul','ago','sep','oct','nov','dic']
        zona=fecha.strftime('%Z')
        return f'{fecha.day} {meses[fecha.month-1]} {fecha.year} · {fecha:%H:%M:%S}'+(' '+zona if zona else '')
    except (TypeError,ValueError):return str(texto or 'Fecha no disponible')


def datos_periodos(horas,columnas,duracion):
    datos=horas[['hora',*columnas]].sort_values('hora').copy()
    datos['Periodo']=datos.hora.map(lambda h:f'{int(h*duracion):02d}:00–{int((h+1)*duracion):02d}:00')
    datos['Tiempo']=datos.hora*duracion
    cierre=datos.iloc[[-1]].copy();cierre['Tiempo']=(datos.hora.iloc[-1]+1)*duracion
    # Punto de dibujo para cerrar el último escalón; no es otra decisión del modelo.
    return pd.concat([datos,cierre],ignore_index=True)


def numero_entrada(n, factor=1):
    # Decimal a partir del texto evita redondear los datos al presentarlos para editar.
    texto = format(Decimal(str(n))*Decimal(str(factor)), ',f')
    if '.' in texto:
        texto = texto.rstrip('0').rstrip('.')
    return texto.translate(str.maketrans({',':'.','.':','}))


def leer_numero(texto, factor=1):
    if isinstance(texto, (int,float)):
        return float(Decimal(str(texto)) / Decimal(str(factor)))
    texto = str(texto).strip().replace(' ', '')
    # Punto para miles, coma para decimales. Se rechaza un punto decimal ambiguo.
    if not re.fullmatch(r'[+-]?(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d+)?', texto):
        return float('nan')
    # Convertir las unidades antes de pasar a float evita dos redondeos binarios.
    return float(Decimal(texto.replace('.','').replace(',','.')) / Decimal(str(factor)))


def tarjetas(items, principal=False, compactas=False):
    html = ''
    for titulo, valor, unidad, nota in items:
        html += (f'<div class="mcoi-card {"mcoi-hero" if principal else ""}">'
                 f'<div class="mcoi-label">{escape(titulo)}</div>'
                 f'<div class="mcoi-value">{escape(valor)}<span class="mcoi-unit">{escape(unidad)}</span></div>'
                 f'<p class="mcoi-note">{escape(nota)}</p></div>')
    st.markdown(html if principal else f'<div class="mcoi-grid {"mcoi-grid-compacto" if compactas else ""}">{html}</div>', unsafe_allow_html=True)


def tabla(nombre, datos, descargar=True, columnas=None):
    # El formato se aplica solo a la vista; CSV y cálculos conservan los floats originales.
    visibles=datos[columnas] if columnas else datos
    formatos = {c:(lambda v: formato(v, 0 if isinstance(v,int) else 2))
                for c in visibles.select_dtypes(include='number').columns}
    for c in ('Hora', 'CT', 'Punto'):
        if c in formatos:
            formatos[c] = lambda v: formato(v,0)
    vista = visibles.style.format(formatos, na_rep='No aplicable')
    st.dataframe(vista, hide_index=True, width='stretch', height='auto')
    if descargar:
        st.download_button('Descargar tabla · CSV', csv_bytes(datos), file_name=nombre+'.csv',
                           mime='text/csv', key='csv_'+nombre)


def grafico_lineas(horas, columnas, unidad, clave, colores=None, explorar=True):
    from vistas_operacion import duracion_periodo
    es_potencia=unidad in ('MW','€/MWh')
    if es_potencia:
        preparada=datos_periodos(horas,columnas,duracion_periodo())
        datos=preparada.rename(columns=columnas).melt(['hora','Tiempo','Periodo'],value_vars=list(columnas.values()),var_name='Serie',value_name='Valor')
    else:
        datos=horas[['hora',*columnas]].rename(columns=columnas).melt('hora',var_name='Serie',value_name='Valor')
        datos['Tiempo']=datos.hora;datos['Periodo']=datos.hora.astype(str)
    datos['Valor mostrado'] = datos['Valor'].map(lambda v:formato(v,3 if unidad=='m' else 2)+' '+unidad)
    nombres = list(columnas.values())
    colores = colores or {n:PALETA.get(n,'#667788') for n in nombres}
    fin=float(datos.Tiempo.max())
    grafico = alt.Chart(datos).mark_line(point=False, strokeWidth=2.3,interpolate='step-after' if es_potencia else 'linear').encode(
        x=alt.X('Tiempo:Q',title='Hora del día · intervalos completos' if es_potencia else 'Hora del día',scale=alt.Scale(domain=[0,fin]),axis=alt.Axis(values=[0,4,8,12,16,20,fin],format='d')),
        y=alt.Y('Valor:Q',title=unidad,scale=alt.Scale(zero=unidad!='m')),
        color=alt.Color('Serie:N',title=None,scale=alt.Scale(domain=nombres,range=[colores[n] for n in nombres]),legend=alt.Legend(orient='bottom')),
        strokeDash=alt.StrokeDash('Serie:N',legend=None),
        tooltip=[alt.Tooltip('Periodo:N',title='Periodo del modelo'),alt.Tooltip('Serie:N'),alt.Tooltip('Valor mostrado:N',title='Valor')]
    ).properties(height=285)
    if explorar:
        from exploracion import desde_grafico
        from functools import partial
        seleccion=alt.selection_point(name='hora',fields=['hora'],nearest=True,on='click',empty=False)
        puntos=alt.Chart(datos).mark_point(opacity=0,size=140).encode(x='Tiempo:Q',y='Valor:Q').add_params(seleccion)
        regla=alt.Chart(pd.DataFrame({'Tiempo':[st.session_state.get('hora_red',0)]})).mark_rule(color='#526777',strokeDash=[4,4]).encode(x='Tiempo:Q')
        grafico=grafico+puntos+regla
        st.altair_chart(grafico.configure(locale={'number':{'decimal':',','thousands':'.','grouping':[3],'currency':['',' €']}}),width='stretch',key=clave,on_select=partial(desde_grafico,clave))
        st.caption('Selecciona una hora en el gráfico para abrir ese periodo en la red. Intervalos de una hora; la marca 24:00 cierra la hora 23.')
    else:
        st.altair_chart(grafico.configure(locale={'number':{'decimal':',','thousands':'.','grouping':[3],'currency':['',' €']}}),width='stretch',key=clave)



def graficos_principales(r, prefijo):
    st.markdown('#### Producción de las centrales')
    grafico_lineas(r['horas'],{c:c for c in 'ABCDEF'},'MW',prefijo+'_produccion',COLORES)
    st.markdown('#### Demanda, generación y aporte neto')
    grafico_lineas(r['horas'],{'demanda':'Demanda','generacion':'Generación bruta','aporte_neto':'Aporte neto'},'MW',prefijo+'_balance')
    st.caption('Aporte neto = generación bruta + compras − ventas − bombeo. Coincide con la demanda atendida; las dos líneas pueden superponerse.')


def graficos_comparacion(datos):
    coste = datos[['Escenario','Coste neto (€)']].copy()
    coste['Coste mostrado'] = coste['Coste neto (€)'].map(lambda v:formato(v)+' €')
    st.markdown('#### Coste neto diario')
    st.altair_chart(alt.Chart(coste).mark_bar(color='#24748D').encode(
        x=alt.X('Coste neto (€):Q',title='Coste neto (€)'),
        y=alt.Y('Escenario:N',sort=None,title=None,axis=alt.Axis(labelLimit=0)),
        tooltip=['Escenario:N','Coste mostrado:N']).properties(height=max(160,len(coste)*44)).configure(locale={'number':{'decimal':',','thousands':'.','grouping':[3],'currency':['',' €']}}),width='stretch',key='comp_coste')
    produccion = datos.melt('Escenario',value_vars=[f'Producción {c} (MWh)' for c in 'ABCDEF'],var_name='Central',value_name='Energía')
    produccion['Central']=produccion['Central'].str.split().str[1]
    produccion['Producción mostrada']=produccion['Energía'].map(lambda v:formato(v)+' MWh')
    st.markdown('#### Producción diaria por central')
    st.altair_chart(alt.Chart(produccion).mark_bar().encode(
        x=alt.X('Energía:Q',title='Producción (MWh)'), y=alt.Y('Escenario:N',sort=None,title=None,axis=alt.Axis(labelLimit=0)),
        color=alt.Color('Central:N',scale=alt.Scale(domain=list(COLORES),range=list(COLORES.values())),legend=alt.Legend(orient='bottom')),
        tooltip=['Escenario:N','Central:N','Producción mostrada:N']).properties(height=max(200,len(coste)*50)).configure(locale={'number':{'decimal':',','thousands':'.','grouping':[3],'currency':['',' €']}}),width='stretch',key='comp_produccion')
