"""Identidad de formulación: los archivos históricos sin etiqueta pertenecen a v1."""
from pathlib import Path
import hashlib

VERSION_MODELO = 'red-2026-10-19'
VERSION_ANTERIOR = 'red-2026-10-18'
SHA_MODELO = hashlib.sha256(Path(__file__).with_name('App.py').read_bytes()).hexdigest()
SHA_ANTERIOR = '56d32e5ed1ca6159cdbbb01109d31b3dbf18c3b6c6a0f2d5b4d5e18575662015'
ORIGINAL_ID = 'caso_original_' + VERSION_MODELO


def version_ejecucion(ejecucion):
    return ejecucion.get('version_modelo', VERSION_ANTERIOR)


def ejecucion_vigente(ejecucion):
    return bool(ejecucion and version_ejecucion(ejecucion) == VERSION_MODELO
                and ejecucion.get('sha_modelo') == SHA_MODELO)
