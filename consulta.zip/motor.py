"""Adaptador de App.py: instancia nueva en cada resolución, sin cambiar ecuaciones."""
import importlib.util
from copy import deepcopy
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
from datos import extraer_datos, validar, huella
from version_modelo import VERSION_MODELO, SHA_MODELO

RUTA_MODELO = Path(__file__).with_name('App.py')


def cargar_motor():
    # No usamos el módulo global compartido por import: cada sesión/ejecución tiene su modelo.
    spec = importlib.util.spec_from_file_location('modelo_ejecucion', RUTA_MODELO)
    modulo = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(modulo)
    return modulo


def optimizar(datos):
    raise RuntimeError("Versión pública de consulta: la optimización está deshabilitada.")
