"""Tablas, comprobaciones y descarga; solo se invoca tras terminación optimal."""
from io import BytesIO
from copy import deepcopy
import json
import math
import zipfile
import pandas as pd
from pyomo.environ import Constraint, Var, SOSConstraint, value

NOMBRES = {
    'hora': 'Hora', 'demanda': 'Demanda (MW)',
    **{c: f'{c} (MW)' for c in 'ABCDEF'},
    'compra': 'Compra (MW)', 'venta': 'Venta (MW)',
    'bombeo_B': 'Bombeo B (MW)', 'bombeo_E': 'Bombeo E (MW)',
    'nivel_B': 'Nivel B (m)', 'nivel_E': 'Nivel E (m)',
    'reserva_termica': 'Reserva térmica (MW)', 'reserva_hidraulica': 'Reserva hidráulica (MW)',
    'reserva_bombeo': 'Reserva de bombeo (MW)', 'reserva_total': 'Reserva total (MW)',
}
VARIABLES = {
    'PT': 'Producción térmica (MW)', 'PH': 'Producción hidráulica (MW)', 'PN': 'Producción nuclear (MW)',
    'F': 'Flujo de línea (MW)', 'NAH': 'Nivel final del periodo (m)', 'PB': 'Bombeo (MW)',
    'COMP': 'Compra exterior (MW)', 'VENT': 'Venta exterior (MW)', 'lam': 'Peso SOS2',
    'CEXTN': 'Coste extra nuclear (€ por periodo)', 'RT': 'Reserva térmica (MW)',
    'RH': 'Reserva hidráulica (MW)', 'RB': 'Reserva de bombeo (MW)',
    'alphaT': 'Encendida térmica (0/1)', 'alphaH': 'Generando hidráulica (0/1)',
    'alphaN': 'Encendida nuclear (0/1)', 'aT': 'Arranque térmico (0/1)',
    'aH': 'Arranque hidráulico (0/1)', 'aN': 'Arranque nuclear (0/1)',
    'alphaBH': 'Bombeo habilitado (0/1)', 'betaCOMP': 'Compra habilitada (0/1)',
    'betaVENT': 'Venta habilitada (0/1)',
}


def comprobar_solucion(m, tolerancia=1e-6, tol_entera=1e-5):
    """Residuos absolutos de ecuaciones/cotas y tolerancia de integridad de Gurobi."""
    residuos, cotas, enteros, fallos_sos = [], [], [], []
    for v in m.component_data_objects(Var):
        x = value(v, exception=False)
        if x is None or not math.isfinite(x):
            return {'valida': False, 'motivo': f'Valor ausente o no finito: {v.name}'}
        if v.lb is not None:
            cotas.append(max(0, value(v.lb) - x))
        if v.ub is not None:
            cotas.append(max(0, x - value(v.ub)))
        if v.is_integer():
            enteros.append(abs(x - round(x)))
    for c in m.component_data_objects(Constraint, active=True):
        x = value(c.body)
        residual = max(0, value(c.lower) - x if c.has_lb() else 0,
                       x - value(c.upper) if c.has_ub() else 0)
        residuos.append((c.name, residual))
    for s in m.component_data_objects(SOSConstraint, active=True):
        pares = sorted(s.get_items(), key=lambda item: item[1])
        activos = [i for i, (v, _) in enumerate(pares) if abs(value(v)) > tol_entera]
        if len(activos) > 2 or (len(activos) == 2 and activos[1] - activos[0] != 1):
            fallos_sos.append(s.name)
    peor = max(residuos, key=lambda t: t[1], default=('', 0))
    max_cota, max_entero = max(cotas, default=0), max(enteros, default=0)
    return {'valida': peor[1] <= tolerancia * 1.01 and max_cota <= tolerancia * 1.01 and max_entero <= tol_entera * 1.01 and not fallos_sos,
            'max_residuo_restricciones': peor[1], 'restriccion_mayor_residuo': peor[0],
            'max_violacion_cotas': max_cota, 'max_error_integridad': max_entero,
            'fallos_SOS2': fallos_sos, 'tolerancia_factibilidad': tolerancia,
            'tolerancia_integridad_SOS2': tol_entera, 'restricciones_comprobadas': len(residuos)}


def desglose_costes(m):
    filas = []
    for i in m.I:
        bloques = {
            'Térmicas · mínimo': sum(value(m.CMINT[t] * m.alphaT[t, i]) for t in m.T),
            'Térmicas · extra': sum(value(m.CEXTT[t] * (m.PT[t, i] - m.nminT[t] * m.NMAXT[t] * m.alphaT[t, i])) for t in m.T),
            'Térmicas · arranque': sum(value(m.CPMT[t] * m.aT[t, i]) for t in m.T),
            'Hidráulicas · funcionamiento': sum(value(m.CHH[h] * m.alphaH[h, i]) for h in m.H),
            'Hidráulicas · arranque': sum(value(m.CPMH[h] * m.aH[h, i]) for h in m.H),
            'Nuclear · mínimo': sum(value(m.CMINN[n] * m.alphaN[n, i]) for n in m.N),
            'Nuclear · extra': sum(value(m.CEXTN[n, i]) for n in m.N),
            'Nuclear · arranque': sum(value(m.CPMN[n] * m.aN[n, i]) for n in m.N),
            'Mercado · compra': sum(value(m.PC[i] * m.COMP[c, i] * m.Delta_t) for c in m.CEXT),
            'Mercado · venta (ingreso negativo)': -sum(value(m.PV[i] * m.VENT[c, i] * m.Delta_t) for c in m.CEXT),
        }
        filas.extend({'Hora': i, 'Concepto': k, 'Coste (€)': v} for k, v in bloques.items())
    return pd.DataFrame(filas)


def procesar_resultados(m, bruto, datos):
    verificacion = comprobar_solucion(m)
    horas = pd.DataFrame(bruto['horas'])
    horas['generacion'] = horas[list('ABCDEF')].sum(axis=1)
    horas['bombeo'] = horas['bombeo_B'] + horas['bombeo_E']
    horas['reserva_requerida'] = horas['demanda'] * value(m.PR)
    horas['margen_reserva'] = horas['reserva_total'] - horas['reserva_requerida']
    horas['aporte_neto'] = horas['generacion'] + horas['compra'] - horas['venta'] - horas['bombeo']
    horas['error_balance'] = horas['aporte_neto'] - horas['demanda']
    costes_hora = desglose_costes(m)
    costes = costes_hora.groupby('Concepto', sort=False, as_index=False)['Coste (€)'].sum()
    objetivo = float(value(m.objetivo))
    error_coste = abs(float(costes['Coste (€)'].sum()) - objetivo)
    verificacion['error_desglose_coste_euros'] = error_coste
    verificacion['error_coste_funcion_original_euros'] = abs(bruto['coste_total'] - round(objetivo, 2))
    verificacion['valida'] &= math.isfinite(objetivo) and error_coste < 1e-5 and verificacion['error_coste_funcion_original_euros'] < 1e-7
    nombres = {**NOMBRES, 'generacion': 'Generación total (MW)', 'bombeo': 'Bombeo total (MW)',
               'reserva_requerida': 'Reserva requerida (MW)', 'margen_reserva': 'Margen de reserva (MW)',
               'aporte_neto': 'Aporte neto a demanda (MW)', 'error_balance': 'Error de balance (MW)'}
    demanda_ct = pd.DataFrame([
        {'Hora': i, 'CT': c, 'Demanda (MW)': value(m.D[c, i]),
         'Suministro (MW)': sum(value(m.F[l, i]) for l in m.L if l.endswith(str(c)))}
        for i in m.I for c in m.C
    ])
    uso_lineas = pd.DataFrame([
        {'Hora': i, 'Línea': l, 'Flujo (MW)': value(m.F[l, i]), 'Capacidad (MW)': value(m.CAP[l]),
         'Utilización (%)': abs(value(m.F[l, i])) / value(m.CAP[l]) * 100 if value(m.CAP[l]) > 0 else None}
        for i in m.I for l in m.L
    ])
    variables = []
    for componente in m.component_objects(Var):
        for k in componente:
            indices = k if isinstance(k, tuple) else (k,)
            variables.append({'Variable': componente.name, 'Significado': VARIABLES[componente.name],
                              'Elemento': str(indices[0]) if len(indices) > 1 else '',
                              'Hora': indices[-1], 'Valor': value(componente[k])})
    tablas = {
        'balance_horario': horas[['hora','demanda',*list('ABCDEF'),'generacion','compra','venta','bombeo','aporte_neto','error_balance']].rename(columns=nombres),
        'embalses': horas[['hora','bombeo_B','bombeo_E','nivel_B','nivel_E']].rename(columns=nombres),
        'reservas': horas[['hora','reserva_termica','reserva_hidraulica','reserva_bombeo','reserva_total','reserva_requerida','margen_reserva']].rename(columns=nombres),
        'flujos': pd.DataFrame(bruto['flujos']).rename(columns={'hora': 'Hora', **{l: f'{l} (MW)' for l in m.L}}),
        'utilizacion_lineas': uso_lineas, 'demanda_por_centro': demanda_ct,
        'costes': costes, 'costes_por_hora': costes_hora, 'todas_las_variables': pd.DataFrame(variables),
    }
    return {'coste_total': objetivo, 'horas': horas, 'tablas': tablas, 'datos': deepcopy(datos),
            'verificacion': verificacion, 'demanda_MWh': float(horas['demanda'].sum() * value(m.Delta_t)),
            'generacion_MWh': float(horas['generacion'].sum() * value(m.Delta_t)),
            'margen_reserva_minimo': float(horas['margen_reserva'].min()),
            'nivel_minimo': value(m.LIH), 'nivel_maximo': value(m.LSH)}


def csv_bytes(tabla):
    return tabla.to_csv(index=False, sep=';', decimal=',').encode('utf-8-sig')


def descargar_zip(ejecucion):
    r = ejecucion['resultados']
    memoria = BytesIO()
    with zipfile.ZipFile(memoria, 'w', zipfile.ZIP_DEFLATED) as z:
        for nombre, tabla in r['tablas'].items():
            z.writestr(nombre + '.csv', csv_bytes(tabla))
        z.writestr('parametros.json', json.dumps(r['datos'], ensure_ascii=False, indent=2))
        z.writestr('resolucion.json', json.dumps({k: v for k, v in ejecucion.items() if k != 'resultados'}, ensure_ascii=False, indent=2))
        z.writestr('verificacion.json', json.dumps(r['verificacion'], ensure_ascii=False, indent=2))
        z.writestr('LEEME.txt', 'Resultados del escenario identificado en resolucion.json. CSV UTF-8, separador punto y coma, decimal coma. Potencias MW, niveles m, costes EUR. Periodos de 1 h. Flujos positivos de central/exterior a CT; negativos en sentido contrario. Nivel de agua al final de cada hora. Parametros porcentuales en fracción en parametros.json. Óptimo según tolerancias de Gurobi.\n')
    return memoria.getvalue()
