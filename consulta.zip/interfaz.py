"""Interfaz local: copia editable, biblioteca persistente y resultados independientes."""
from copy import deepcopy
import json
import pandas as pd
import streamlit as st
from datos import META, GRUPOS, extraer_datos, tabla_grupo, validar, desactualizado, huella
from motor import cargar_motor, optimizar
from resultados import descargar_zip
from informe import crear_pdf
from exploracion import cambios_entrada,restaurar_bloque,mostrar_conclusiones
from vistas_operacion import duracion_periodo
from red_vista import mostrar_red
from vistas_operacion import mostrar_costes, mostrar_embalses
from version_modelo import VERSION_MODELO, ORIGINAL_ID, ejecucion_vigente, version_ejecucion
from escenarios import (CARPETA, asegurar_original, leer_escenarios, guardar_escenario,
                        duplicar_escenario, estado_escenario, es_optimo, guardar_referencia,
                        leer_referencia, comparar, cambios_parametros)
from presentacion import (estilo, tarjetas, formato, fecha_legible, tabla, numero_entrada, leer_numero,
                          grafico_lineas, graficos_principales, graficos_comparacion, COLORES)

st.set_page_config(page_title='Red eléctrica · MCOI', page_icon='⚡', layout='wide')
estilo()


@st.cache_data
def valores_originales(version=VERSION_MODELO):
    return extraer_datos(cargar_motor().model)


@st.cache_data(show_spinner=False)
def informe_descarga(ejecucion,originales):
    return crear_pdf(ejecucion,originales,duracion_periodo())


def cargar_copia(s):
    for clave in list(st.session_state):
        if clave.startswith(('e_', 's_')):
            del st.session_state[clave]
    # Una carga crea controles nuevos también en el navegador, aunque se repita
    # el mismo escenario. Borrar solo session_state no reinicia su estado visual.
    st.session_state['revision_edicion'] = st.session_state.get('revision_edicion', 0) + 1
    st.session_state['base_edicion'] = deepcopy(s['parametros'])
    st.session_state['datos_actuales'] = deepcopy(s['parametros'])
    st.session_state['ejecucion'] = deepcopy(s.get('ejecucion'))
    if st.session_state['ejecucion']:
        st.session_state['ejecucion']['escenario'] = s['nombre']
        st.session_state['ejecucion']['descripcion_escenario'] = s['descripcion']
    st.session_state['origen_nombre'] = s['nombre']
    st.session_state['origen_id'] = s['id']
    st.session_state['nombre_guardar'] = 'Experimento 1' if s['id'] == ORIGINAL_ID else s['nombre']
    st.session_state['descripcion_guardar'] = '' if s['id'] == ORIGINAL_ID else s['descripcion']


def restablecer():
    anterior = st.session_state.get('ejecucion')
    s = {'id':ORIGINAL_ID,'nombre':'Caso original','parametros':valores_originales(), 'descripcion':'','ejecucion':anterior}
    cargar_copia(s)
    # Conservar la identidad de la ejecución anterior; la huella decide su vigencia.
    st.session_state['ejecucion'] = anterior
    st.session_state['notificacion'] = 'Configuración original restablecida. La biblioteca de escenarios se conserva.'


def clave_control(nombre):
    return f"{nombre}__{st.session_state['revision_edicion']}"


def resultados_vigentes(ejecucion, datos):
    return es_optimo({'parametros': datos, 'ejecucion': ejecucion})


def editor(grupo, datos, base):
    titulo, indice, parametros = GRUPOS[grupo]
    st.markdown(f'#### {titulo}')
    entrada = tabla_grupo(base, grupo)
    for p in parametros:
        entrada[p] = [numero_entrada(base[p][k], META[p][5]) for k in base[p]]
    config = {indice:st.column_config.Column(indice,disabled=True,pinned=True)}
    for p in parametros:
        nombre, unidad, ayuda, *_ = META[p]
        config[p] = st.column_config.TextColumn(f'{nombre} ({unidad})', help=ayuda+' Usa coma decimal.',required=True,width='medium')
    editada=st.data_editor(entrada, key=clave_control('e_'+grupo),column_config=config,hide_index=True,num_rows='fixed',width='stretch',disabled=True)
    for p in parametros:
        datos[p] = {fila[indice]:leer_numero(fila[p], META[p][5]) for fila in editada.to_dict('records')}
    mostrar_cambios_bloque(parametros,datos)
    campos=parametros+(['LIH','LSH','ES','MB'] if grupo=='hidraulicas' else [])
    st.button('Restablecer este bloque',disabled=True,key='restaurar_'+grupo,on_click=restaurar_bloque,args=(campos,originales),help='Conserva los cambios de otros bloques y todos los escenarios guardados.')
    with st.expander('Qué significa cada dato'):
        for p in parametros:
            st.markdown(f'**{META[p][0]}** ({p}): {META[p][2]}')


def escalar(p, datos, base):
    nombre, unidad, ayuda, _, _, factor = META[p]
    texto=st.text_input(f'{nombre} ({unidad})',value=numero_entrada(base[p],factor),help=ayuda+' Usa coma decimal y punto para miles.',key=clave_control('s_'+p),disabled=True)
    datos[p]=leer_numero(texto, factor)
    st.caption('Original: '+numero_entrada(originales[p],factor)+' '+unidad+(' · Modificado' if datos[p]!=originales[p] else ' · Sin cambios'))
    for mensaje in validar(datos,originales)[0]:
        if mensaje.startswith(nombre) or (p in ('LIH','LSH') and 'nivel mínimo' in mensaje):st.error(mensaje)



def mostrar_cambios_bloque(parametros,datos):
    cambios=cambios_entrada(datos,originales)
    cambios=cambios[cambios['Símbolo'].isin(parametros)]
    if not cambios.empty:
        st.caption(f'✎ {len(cambios)} valores modificados respecto al caso original')
        with st.expander('Ver valores originales y actuales',expanded=len(cambios)<=4):
            vista=cambios[['Parámetro','Índice','Referencia','Escenario comparado','Unidad']].rename(columns={'Referencia':'Original','Escenario comparado':'Actual'})
            st.dataframe(vista.style.format({'Original':numero_entrada,'Actual':numero_entrada}).set_properties(subset=['Actual'],**{'background-color':'#E3F1EB','color':'#145A4C','font-weight':'bold'}),hide_index=True,width='stretch')
    etiquetas=[META[p][0] for p in parametros]
    for mensaje in validar(datos,originales)[0]:
        if any(mensaje.startswith(x) for x in etiquetas) or ('PEX' in parametros and mensaje.startswith('SOS2')) or ('NIH' in parametros and mensaje.startswith('Embalse')):st.error(mensaje)


def ejecucion_descarga(s):
    e=deepcopy(s['ejecucion'])
    e['escenario']=s['nombre']
    e['descripcion_escenario']=s['descripcion']
    return e


def mostrar_comparacion(registros):
    st.subheader('Comparar escenarios guardados')
    st.caption('Se utilizan exclusivamente los parámetros y resultados guardados. La configuración editable no interviene en la comparación. Solo se comparan resultados de la formulación vigente; los históricos se conservan y permiten recuperar sus parámetros para resolverlos de nuevo.')
    validos={s['id']:s for s in registros if es_optimo(s)}
    excluidos=[f"{s['nombre']}: {estado_escenario(s)}" for s in registros if not es_optimo(s)]
    if excluidos:
        with st.expander('Escenarios sin resultados comparables'):
            for texto in excluidos: st.write(texto)
    if not validos:
        st.info('Guarda al menos un escenario con resolución óptima para comparar resultados.')
        return
    preferida=st.session_state.get('referencia_consulta',ORIGINAL_ID)
    ids=list(validos)
    if st.session_state.get('referencia_comparar') not in validos:
        st.session_state['referencia_comparar']=preferida if preferida in validos else ids[0]
    ref_id=st.selectbox('Escenario de referencia',ids,format_func=lambda k:validos[k]['nombre'],key='referencia_comparar')
    st.session_state['referencia_consulta']=ref_id
    candidatos=[k for k in ids if k!=ref_id]
    seleccion=st.multiselect('Escenarios que quieres comparar',candidatos,format_func=lambda k:validos[k]['nombre'],default=candidatos[:2],key='comparados')
    if not seleccion:
        st.info('Selecciona al menos otro escenario óptimo. Puedes guardar un experimento desde la barra lateral.')
    else:
        ref=validos[ref_id]
        otros=[validos[k] for k in seleccion]
        resumen=comparar(ref,[ref,*otros])
        st.caption('Diferencia = coste del escenario − coste de referencia. El porcentaje usa el valor absoluto del coste de referencia; si es cero, no es aplicable. Una diferencia negativa indica reducción del coste.')
        st.info('Referencia: '+ref['nombre']+' · '+formato(resumen.iloc[0]['Coste neto (€)'])+' € de coste neto.')
        for fila in resumen.iloc[1:].to_dict('records'):
            diferencia=fila['Diferencia (€)'];porcentaje=fila['Diferencia (%)']
            cambio='reducción' if diferencia<0 else 'incremento' if diferencia>0 else 'sin variación'
            texto=(f"{abs(porcentaje):.2f}".replace('.',',')+' %') if pd.notna(porcentaje) else 'porcentaje no aplicable: referencia con coste cero'
            st.write(f"**{fila['Escenario']}**: {cambio} de **{formato(abs(diferencia))} €** respecto a {ref['nombre']} ({texto}).")
            delta_generacion=fila['Producción total (MWh)']-resumen.iloc[0]['Producción total (MWh)']
            delta_compra=fila['Compra (MWh)']-resumen.iloc[0]['Compra (MWh)']
            delta_venta=fila['Venta (MWh)']-resumen.iloc[0]['Venta (MWh)']
            st.caption(f"Variación de producción: {formato(delta_generacion)} MWh · compras: {formato(delta_compra)} MWh · ventas: {formato(delta_venta)} MWh. Diferencias descriptivas; no se atribuye causalidad ni se equipara una reducción de coste con beneficio.")
        tabla('comparacion_escenarios',resumen,columnas=['Escenario','Coste neto (€)','Diferencia (€)','Diferencia (%)'])
        with st.expander('Detalle energético y técnico de la comparación'):
            tabla('comparacion_detalle',resumen)
        graficos_comparacion(resumen)
        st.markdown('#### Parámetros que han cambiado')
        cambios=cambios_parametros(ref,otros)
        if cambios.empty: st.info('Los escenarios seleccionados tienen los mismos parámetros que la referencia.')
        else:
            tabla('cambios_parametros',cambios)
            st.caption('Este resumen relaciona cambios de datos y resultados; no demuestra causalidad. Cuando cambian varios parámetros, no se atribuye la diferencia de coste a uno de ellos.')
    with st.expander('Consultar y descargar un escenario guardado'):
        guardado_id=st.selectbox('Escenario guardado',ids,format_func=lambda k:validos[k]['nombre'],key='descarga_guardado')
        s=validos[guardado_id]
        st.write(s['descripcion'] or 'Sin descripción.')
        st.caption('Ejecución: '+fecha_legible(s['ejecucion']['fecha']))
        st.download_button('Descargar escenario guardado · ZIP',descargar_zip(ejecucion_descarga(s)),file_name='escenario_'+s['id']+'.zip',mime='application/zip',key='zip_biblioteca')
        st.download_button('Descargar informe guardado · PDF',informe_descarga(ejecucion_descarga(s),originales),file_name='informe_'+s['id']+'.pdf',mime='application/pdf',key='pdf_guardado')
        tablas=s['ejecucion']['resultados']['tablas']
        tipo=st.selectbox('Tabla guardada',list(tablas),key='tabla_guardada')
        tabla('guardado_'+tipo,tablas[tipo])


originales=valores_originales()
try:
    original=asegurar_original(originales)
except (OSError,ValueError) as exc:
    st.error(f'No se pudo abrir la biblioteca local: {exc}')
    st.stop()
if 'cargar_pendiente' in st.session_state:
    cargar_copia(st.session_state.pop('cargar_pendiente'))
if 'base_edicion' not in st.session_state:
    cargar_copia(original)
# Al actualizar una sesión abierta con la versión anterior, preservar sus ediciones.
if 'revision_edicion' not in st.session_state:
    st.session_state['base_edicion'] = deepcopy(st.session_state.get('datos_actuales', st.session_state['base_edicion']))
    st.session_state['revision_edicion'] = 0
base_edicion=st.session_state['base_edicion']
datos=deepcopy(base_edicion)
with st.container(key='mcoi_portada'):
    st.markdown('<div class="mcoi-cabecera"><div class="mcoi-identidad">'
                '<svg class="mcoi-simbolo" viewBox="0 0 36 36" aria-hidden="true" focusable="false">'
                '<path d="M6 25L17 7L30 17L22 30Z M6 25L30 17 M17 7L22 30" fill="none" stroke="#367C82" stroke-width="1.5" stroke-linejoin="round"/>'
                '<circle cx="6" cy="25" r="3.5" fill="#24776F"/><circle cx="17" cy="7" r="4" fill="#163B50"/>'
                '<circle cx="30" cy="17" r="3.5" fill="#24776F"/><circle cx="22" cy="30" r="3" fill="#638C9D"/></svg>'
                '<div class="mcoi-firma"><span class="mcoi-codigo">MCOI</span><span class="mcoi-separador" aria-hidden="true">·</span>'
                '<span class="mcoi-descriptor">OPERACIÓN DEL SISTEMA</span></div></div>'
                '<h1>Red <span class="mcoi-titulo-acento">eléctrica</span></h1><p>Comprende la red, explora sus escenarios y explica sus resultados.</p></div>',unsafe_allow_html=True)
    with st.container(key='mcoi_modo'):
        with st.popover('Opciones',icon=':material/more_horiz:',type='tertiary',help='Opciones de presentación',key='opciones_presentacion'):
            st.toggle('Modo defensa',key='modo_defensa',help='Más espacio para resultados y red. Conserva el escenario y la hora.')
if st.session_state.get('modo_defensa'):
    st.markdown('<style>[data-testid="stSidebar"]{display:none;}[data-testid="stSidebarCollapsedControl"]{display:none;}.block-container{max-width:1650px;}</style>',unsafe_allow_html=True)
if mensaje:=st.session_state.pop('notificacion',None): st.success(mensaje)
# La clave conserva la identidad aunque el modo defensa añada un bloque de estilo.
# El seguimiento nativo de Streamlit conserva la pestaña activa en cada rerun.
informacion,parametros,resolucion=st.tabs(['Información del caso','Parámetros y experimentación','Resolución y resultados'],key='pestana_principal',on_change='rerun')
with informacion:
    from pathlib import Path

    st.subheader('Abastecer la red al menor coste')
    st.write('Imagina que eres el operador de esta red: debes coordinar un día completo de producción para atender la demanda de cinco centros de transformación. Cada hora tienes que decidir qué centrales utilizar, cuánto producir y cómo hacer llegar la energía a su destino.')
    tarjetas([
        ('Un día de planificación','24','periodos de una hora','Desde las 00:00 hasta las 24:00.'),
        ('Recursos de generación','6','centrales','Tres térmicas, dos hidráulicas reversibles y una nuclear.'),
        ('La red que conecta el sistema','5','centros de transformación','15 líneas y conexión con el exterior en los centros 1 y 5.')
    ],compactas=True)

    esquema,lectura=st.columns([1.15,1],gap='large',vertical_alignment='center')
    with esquema:
        with st.container(border=True):
            st.image(str(Path(__file__).resolve().parent/'recursos'/'red_enunciado.png'),width='stretch',
                     caption='Figura 2 del enunciado · Configuración de la red eléctrica · página 5.')
    with lectura:
        st.markdown('#### Aprende a leer el esquema')
        st.markdown('**Las letras A–F son las centrales.** Producen la energía que circula por la red.')
        st.markdown('**Los círculos numerados 1–5 son los centros de transformación.** En ellos se atiende la demanda eléctrica.')
        st.markdown('**Los trazos son las conexiones.** La energía solo puede circular por las líneas disponibles y cada una tiene una capacidad limitada.')
        st.markdown('**Los centros 1 y 5 conectan con el exterior.** Permiten incorporar las compras o dar salida a las ventas de energía.')
        st.caption('Este es el dibujo original del caso. Los flujos por hora y los estados de las centrales se consultan en «Resolución y resultados → Reserva y red».')

    st.markdown('#### Explora cómo funciona el caso')
    tema_intro=st.radio('Elige un aspecto del sistema',
        ['Demanda y transporte','Producción y bombeo','Decisiones y coste'],
        horizontal=True,key='intro_tema')
    with st.container(border=True):
        if tema_intro=='Demanda y transporte':
            st.markdown('##### La demanda cambia a lo largo del día')
            st.write('Cada centro tiene una demanda máxima propia. El porcentaje horario del caso se aplica a ese máximo para obtener la potencia que necesita en cada periodo. No basta con producir suficiente: también hay que poder transportarla hasta cada centro.')
            hora_intro=st.select_slider('Hora ilustrativa del caso original',options=list(range(24)),
                format_func=lambda h:f'{h:02d}:00–{h+1:02d}:00',key='intro_hora')
            factor_intro=originales['d'][hora_intro]
            tarjetas([
                ('Porcentaje horario',formato(factor_intro*100,0),'% del máximo','El mismo perfil horario se aplica a los cinco centros.'),
                ('Demanda total de este periodo',formato(sum(originales['DM'].values())*factor_intro,2),'MW','Suma de la demanda de los cinco centros.')
            ],compactas=True)
            st.caption('Ejemplo de lectura con los datos originales. Este selector solo cambia la explicación: no modifica los parámetros del escenario activo ni utiliza resultados de una optimización.')
        elif tema_intro=='Producción y bombeo':
            st.markdown('##### Tres tecnologías, decisiones diferentes')
            st.markdown('**Térmicas A, C y F.** Cuando están encendidas, producen entre su mínimo técnico y su potencia máxima. Arrancarlas y mantenerlas en funcionamiento tiene un coste.')
            st.markdown('**Nuclear D.** También tiene un mínimo y un máximo de producción. Su coste extra se representa mediante la curva por tramos del modelo.')
            st.markdown('**Hidráulicas reversibles B y E.** Pueden generar a potencia fija o consumir electricidad para bombear agua al depósito superior. No pueden hacer ambas cosas en la misma hora.')
            generar,bombear=st.columns(2)
            with generar:
                st.info('↓ GENERAR\n\nEl agua desciende, se produce electricidad y baja el nivel del depósito superior.')
            with bombear:
                st.info('↑ BOMBEAR\n\nSe consume electricidad para elevar agua y aumenta el nivel del depósito superior.')
            st.caption('El agua disponible y sus límites conectan las decisiones de unas horas con las siguientes. El bombeo se contabiliza como consumo, no como generación.')
        else:
            st.markdown('##### Encender, repartir y comprobar')
            st.markdown('**1. Programar las centrales.** Decidir cuáles se encienden, cuándo arrancan y cuánto producen en cada hora.')
            st.markdown('**2. Coordinar agua y mercado.** Elegir cuándo generar o bombear y cuánto comprar o vender a través de los centros 1 y 5.')
            st.markdown('**3. Respetar los límites.** Cerrar los balances, respetar las capacidades de las líneas y los niveles de agua, y disponer de la reserva exigida.')
            st.success('Objetivo: minimizar el coste neto del día. Se suman funcionamiento, producción extra, arranques y compras, y se restan los ingresos por ventas.')
            st.caption('Una solución más barata debe seguir cumpliendo todas las restricciones. La reserva es capacidad disponible para responder a un aumento de demanda; no es producción adicional ya suministrada.')

    st.markdown('#### La igualdad que debe cumplirse en cada hora')
    st.latex(r'\text{Generación} + \text{Compras} = \text{Demanda} + \text{Ventas} + \text{Bombeo}')
    st.caption('La generación es bruta: para conocer el aporte a la demanda hay que sumar compras y descontar ventas y consumo de bombeo. El modelo también cierra el balance de cada central y de cada centro, sin pérdidas en las líneas.')

    st.markdown('#### Cómo recorrer la aplicación')
    st.markdown('**1 · Comprende el caso aquí.** Identifica los recursos, las conexiones y las decisiones.\n\n**2 · Consulta los datos.** Selecciona un escenario guardado desde la barra lateral y revisa sus parámetros.\n\n**3 · Interpreta su solución.** Explora los resultados, recorre la red por horas y compara los escenarios calculados. La optimización de nuevos casos está disponible en la aplicación local.')

    with st.expander('Restricciones y supuestos del modelo'):
        st.markdown('''
    - **Demanda y red:** balance en cada central y centro, sin pérdidas; líneas térmicas y nucleares solo hacia los centros; líneas hidráulicas con sentido ligado a generación o bombeo; conexiones exteriores en ambos sentidos. Cada línea respeta su capacidad.
    - **Térmicas y nuclear:** generación entre mínimo técnico y máximo al estar encendidas. Se supone que todas están apagadas antes de la hora 0. No se modelan rampas ni tiempos mínimos de encendido.
    - **Hidráulicas:** producción fija al generar; generación y bombeo incompatibles en cada central y hora. No hay aportes naturales de agua. El nivel se calcula al final de cada periodo, se mantiene entre sus límites también en la hora 23. No se exige recuperar el nivel inicial al terminar el día.
    - **Nuclear:** coste extra interpolado con seis puntos SOS2; como máximo dos pesos consecutivos pueden ser positivos. Se interpolan los costes totales PEX × PREC.
    - **Mercado:** compra y venta no simultáneas en el mismo centro y hora; sí pueden ocurrir en centros distintos.
    - **Reserva:** margen de térmicas encendidas + capacidad hidráulica que no está generando + bombeo interrumpible. Debe cubrir el porcentaje requerido de demanda. La reserva nuclear no participa. No hay una simulación adicional de su activación o transporte por las líneas.
    ''')
    st.markdown('#### Unidades y coste')
    st.write('Potencias y flujos en MW, energía en MWh, niveles en metros y coste diario en euros. Cada periodo dura una hora y su duración no se edita. El objetivo suma funcionamiento, producción extra y arranques, más compras y menos ingresos por ventas.')
    with st.expander('Origen de los datos y revisión de materiales'):
        st.write('Los valores tabulados de demanda, generación y red coinciden con el enunciado. El manuscrito aclara las variables, los balances, el sentido positivo de los flujos y la aproximación nuclear. La reserva está en App.py y en el enunciado, pero no aparece desarrollada en las fotos recibidas.')
        st.write('Hipótesis de App.py: precios horarios de Proyecto_final.py, capacidades exteriores 500 MW, niveles iniciales 10 m, centrales inicialmente apagadas y niveles finales dentro de sus límites, sin obligación de recuperar el inicial. MB = 33.000 MW es un límite por central, común a ambas, confirmado por el usuario frente a la anotación del manuscrito.')
        st.write('La gráfica nuclear del enunciado no proporciona una tabla exacta. Se conservan los puntos PEX y PREC de App.py y la interpretación de coste del manuscrito. Ante cualquier duda se conserva App.py, por indicación del usuario.')
        st.caption('App.py incorpora los cambios de capacidad, nivel terminal y precios de Proyecto_final.py; conserva los contratos de la aplicación. Los valores iniciales se extraen de sus parámetros mutables.')
with parametros:
    st.subheader('Parámetros del escenario consultado')
    st.info('Estos son los parámetros exactos de la solución guardada seleccionada. En esta versión pública son de solo lectura. Para realizar experimentos y optimizar se utiliza la aplicación local.')
    st.caption(f'{len(META)} parámetros mutables · conjuntos y dimensiones fijos · datos derivados de solo lectura')
    with st.expander('Demanda', expanded=True):
        editor('demanda_ct', datos, base_edicion)
        editor('demanda_hora', datos, base_edicion)
    with st.expander('Centrales térmicas'):
        editor('termicas', datos, base_edicion)
    with st.expander('Hidráulicas y embalses'):
        editor('hidraulicas', datos, base_edicion)
        st.markdown('#### Parámetros comunes')
        columnas = st.columns(2)
        for j,p in enumerate(['LIH','LSH','ES','MB']):
            with columnas[j % 2]: escalar(p, datos, base_edicion)
        st.caption('MB se aplica a cada central. No obliga a bombear ni representa un límite conjunto de B y E.')
    with st.expander('Nuclear y curva SOS2'):
        editor('nuclear', datos, base_edicion)
        editor('sos2', datos, base_edicion)
        st.caption('Si cambias la potencia nuclear, revisa también el alcance de los puntos SOS2. No se ajustan automáticamente.')
    with st.expander('Mercado exterior'):
        editor('mercado', datos, base_edicion)
    with st.expander('Red'):
        editor('red', datos, base_edicion)
    with st.expander('Reserva'):
        escalar('PR', datos, base_edicion)
        st.button('Restablecer reserva',disabled=True,key='restaurar_reserva',on_click=restaurar_bloque,args=(['PR'],originales))
    errores, avisos = validar(datos, originales)
    st.session_state['datos_actuales'] = deepcopy(datos)
    for e in errores: st.error(e)
    for a in avisos: st.warning(a)
    cambios_actuales=cambios_entrada(datos,originales)
    with st.expander(f'Resumen del experimento · {len(cambios_actuales)} valores modificados',expanded=False):
        if cambios_actuales.empty:st.write('La configuración coincide con el caso original.')
        else:tabla('cambios_editables',cambios_actuales)
    with st.expander('Vista previa de demanda y precios · datos de entrada',expanded=False):
        st.caption('VISTA PREVIA · se actualiza al confirmar los datos. No son resultados de optimización y no se ejecuta el solver.')
        if errores:st.info('Corrige los errores para visualizar los perfiles completos.')
        else:
            perfil=pd.DataFrame({'hora':list(datos['d']),'demanda':[sum(datos['DM'].values())*v for v in datos['d'].values()],
                                 'compra':[datos['PC'][i] for i in datos['d']],'venta':[datos['PV'][i] for i in datos['d']]})
            grafico_lineas(perfil,{'demanda':'Demanda prevista'},'MW','previa_demanda',explorar=False)
            grafico_lineas(perfil,{'compra':'Precio de compra','venta':'Precio de venta'},'€/MWh','previa_precios',explorar=False)
    with st.expander('Datos calculados automáticamente · solo lectura'):
        st.caption('D[c,i] = DM[c] × d[i]. CEX[k] = PEX[k] × PREC[k]. Pyomo mantiene estas relaciones como expresiones.')
        tabla('demanda_calculada', pd.DataFrame([{'Hora':i, **{f'CT {c} (MW)': dm*datos['d'][i] for c,dm in datos['DM'].items()}} for i in datos['d']]), descargar=False)
        tabla('cex_calculado', pd.DataFrame([{'Punto': k, 'Coste extra CEX (€ por hora)': p*datos['PREC'][k]} for k,p in datos['PEX'].items()]), descargar=False)

# Biblioteca publicada de solo lectura. Cada visitante mantiene su selección en su sesión.
registros, avisos_archivo=leer_escenarios()
with st.sidebar:
    st.markdown('### Escenarios calculados')
    st.caption('Versión pública de consulta · sin ejecución de Gurobi.')
    por_id={s['id']:s for s in registros if es_optimo(s)}
    elegido=st.selectbox('Escenario para consultar',list(por_id),format_func=lambda k:por_id[k]['nombre'],key='archivo_selector')
    guardado=por_id[elegido]
    st.button('Consultar escenario',key='recuperar',on_click=cargar_copia,args=(guardado,),width='stretch')
    st.write('**Activo:** '+st.session_state['origen_nombre'])
    e=st.session_state.get('ejecucion')
    if resultados_vigentes(e,datos):st.success('Resultados óptimos guardados · parámetros correspondientes.')
    else:st.warning('Sin resultados válidos para esta configuración.')
    st.caption(guardado['descripcion'])
    if st.button('Usar como referencia',key='usar_referencia',width='stretch'):
        st.session_state['referencia_consulta']=elegido
        st.session_state['referencia_comparar']=elegido
        st.success('Referencia de comparación seleccionada para esta sesión.')
    st.download_button('Descargar parámetros guardados · JSON',json.dumps(guardado['parametros'],ensure_ascii=False,indent=2),file_name='parametros_'+guardado['id']+'.json',mime='application/json',key='json_guardado')
    st.download_button('Descargar resultados guardados · ZIP',descargar_zip(ejecucion_descarga(guardado)),file_name='escenario_'+guardado['id']+'.zip',mime='application/zip',key='zip_guardado_lateral')
    with st.expander('Cómo utilizar esta versión'):
        st.write('1. Selecciona un escenario y pulsa Consultar escenario.\n\n2. Explora sus parámetros, resultados y red por horas.\n\n3. Compara las soluciones guardadas y descarga sus informes.')
        st.caption('No se calculan soluciones nuevas. Los controles de hora, selección, animación y comparación funcionan sin solver. La aplicación local conserva la edición y la optimización.')
    for aviso in avisos_archivo:st.warning(aviso)

with resolucion:
    st.subheader('Resolución y análisis')
    st.info('Versión pública de consulta. Se muestran soluciones óptimas calculadas previamente; esta web no ejecuta Gurobi ni permite resolver nuevos experimentos.')
    st.button('Optimizar · disponible en la aplicación local',disabled=True,width='stretch',key='optimizar')
    ejecucion=st.session_state.get('ejecucion')
    if errores: st.error('Corrige los datos en Parámetros y experimentación antes de optimizar o guardar.')
    apartado=st.segmented_control('Apartado de resultados',['Resumen','Generación','Mercado','Embalses','Reserva y red','Comparar escenarios'],default='Resumen',required=True,key='apartado',width='stretch',persist_state='session')
    if ejecucion and es_optimo({'parametros':ejecucion.get('parametros'),'ejecucion':ejecucion}):
        with st.expander('Informe de la resolución · PDF'):
            if desactualizado(ejecucion,datos):st.warning('El PDF corresponde a la última solución óptima y sus parámetros, no a las ediciones pendientes.')
            st.caption('Escenario: '+ejecucion.get('escenario','Escenario')+' · '+fecha_legible(ejecucion['fecha']))
            st.download_button('Descargar informe · PDF',informe_descarga(ejecucion,originales),file_name='informe_red_electrica.pdf',mime='application/pdf',key='pdf_actual')
    if apartado=='Comparar escenarios':
        mostrar_comparacion(registros)
    elif apartado=='Reserva y red':
        mostrar_red(ejecucion, datos)
    elif not ejecucion:
        st.info('Pendiente de resolución. Pulsa Optimizar con los parámetros actuales.')
    elif not ejecucion_vigente(ejecucion):
        st.warning('Resultados históricos de ' + version_ejecucion(ejecucion) + '. No son vigentes para ' + VERSION_MODELO + '. Los parámetros están recuperados: pulsa Optimizar para resolverlos con la formulación actual.')
    elif desactualizado(ejecucion,datos):
        st.warning('Resultados desactualizados: hay cambios pendientes de resolver. Las cifras anteriores no corresponden a la configuración actual. Pulsa Optimizar; los escenarios guardados siguen disponibles para comparar.')
        st.caption(f"Última ejecución: {fecha_legible(ejecucion['fecha'])} · {ejecucion['estado']}")
    elif ejecucion['estado']!='optimal':
        st.error(ejecucion['mensaje'])
        st.caption(f"Estado: {ejecucion['estado']} · Terminación: {ejecucion['terminacion'] or 'no disponible'} · {fecha_legible(ejecucion['fecha'])}")
        if ejecucion.get('detalle'):
            with st.expander('Detalle del error'): st.code(ejecucion['detalle'])
        if ejecucion.get('diagnostico'):
            with st.expander('Diagnóstico numérico'): st.json(ejecucion['diagnostico'])
    elif not resultados_vigentes(ejecucion, datos):
        st.warning('Pendiente de resolución: no hay resultados óptimos válidos asociados a estos parámetros y a la versión actual. Pulsa Optimizar.')
    else:
        r=ejecucion['resultados']
        st.success(f"Óptimo · {ejecucion.get('escenario',st.session_state['origen_nombre'])}")
        st.caption(f"Ejecución: {fecha_legible(ejecucion['fecha'])} · Resolución guardada con Gurobi: optimal, dentro de sus tolerancias. No se ha ejecutado el solver en esta web.")
        if apartado=='Resumen':
            tarjetas([('Coste neto total del día',formato(r['coste_total']),'€','Funcionamiento y arranques + compras − ingresos por ventas.')],principal=True)
            tarjetas([('Demanda atendida',formato(r['demanda_MWh'],1),'MWh','Energía suministrada a los cinco centros.'),
                      ('Generación total',formato(r['generacion_MWh'],1),'MWh','Producción bruta acumulada de las seis centrales.'),
                      ('Menor margen de reserva',formato(r['margen_reserva_minimo'],2),'MW','Mínimo horario de reserva disponible menos reserva requerida. Un margen positivo indica holgura.')])
            st.download_button('Descargar todos los resultados · ZIP',descargar_zip(ejecucion),file_name='resultados_red_electrica.zip',mime='application/zip',type='primary',key='zip_actual')
            st.caption('Incluye datos utilizados, tablas sin redondear, estado y comprobación numérica.')
            mostrar_conclusiones(ejecucion,duracion_periodo())
            graficos_principales(r,'resumen')
            with st.expander('Detalle económico · desglose de costes'):
                mostrar_costes(ejecucion)
            with st.expander('Comprobación de la solución'):
                st.write('Se comprueban restricciones, cotas, integridad, SOS2 y coincidencia del desglose con el objetivo sin redondear.')
                st.json(r['verificacion'])
        elif apartado=='Generación':
            grafico_lineas(r['horas'],{c:c for c in 'ABCDEF'},'MW','generacion',COLORES)
            tabla('balance_horario',r['tablas']['balance_horario'])
            with st.expander('Estados, arranques, SOS2 y todas las variables'):
                tabla('todas_las_variables',r['tablas']['todas_las_variables'])
            with st.expander('Demanda y suministro por centro'):
                tabla('demanda_por_centro',r['tablas']['demanda_por_centro'])
        elif apartado=='Mercado':
            tarjetas([('Energía comprada',formato(r['horas']['compra'].sum()*duracion_periodo(),1),'MWh','Total diario de las conexiones exteriores.'),
                      ('Energía vendida',formato(r['horas']['venta'].sum()*duracion_periodo(),1),'MWh','Total diario de las conexiones exteriores.')])
            grafico_lineas(r['horas'],{'compra':'Compra','venta':'Venta'},'MW','mercado')
            tabla('mercado',r['tablas']['balance_horario'][['Hora','Compra (MW)','Venta (MW)']])
            with st.expander('Compras, ventas y modos de operación por centro'):
                t=r['tablas']['todas_las_variables']
                tabla('mercado_por_centro',t[t['Variable'].isin(['COMP','VENT','betaCOMP','betaVENT'])])
        elif apartado=='Embalses':
            mostrar_embalses(ejecucion)
