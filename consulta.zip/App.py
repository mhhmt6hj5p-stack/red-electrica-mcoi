from pyomo.environ import *

# Crear el modelo
model = ConcreteModel()

# CONJUNTOS

# Horas del día
model.I = Set(initialize=range(24))

# Centros de transformación
model.C = Set(initialize=[1, 2, 3, 4, 5])

# Centrales térmicas
model.T = Set(initialize=["A", "C", "F"])

# Centrales hidráulicas
model.H = Set(initialize=["B", "E"])

# Central nuclear
model.N = Set(initialize=["D"])

# Puntos de la curva SOS2
model.K = Set(initialize=[1, 2, 3, 4, 5, 6])

# Líneas de la red
model.L = Set(initialize=[
    "A1", "A4", "A5",
    "B1", "B2",
    "C2", "C3",
    "D2", "D4",
    "E3", "E4",
    "F3", "F5",
    "EXT1", "EXT5"
])





# PARÁMETROS

# PARÁMETROS DE DEMANDA
# Datos de porcentaje de demanda por hora
d = {
    0: 0.85, 1: 0.80, 2: 0.76, 3: 0.60,
    4: 0.68, 5: 0.66, 6: 0.72, 7: 0.70,
    8: 0.70, 9: 0.84, 10: 0.70, 11: 0.65,
    12: 0.95, 13: 0.92, 14: 0.93, 15: 0.83,
    16: 0.85, 17: 0.80, 18: 0.85, 19: 0.86,
    20: 0.90, 21: 1.00, 22: 0.99, 23: 0.80
}

# Datos de demanda máxima de cada CT
DM = {
    1: 250,
    2: 1000,
    3: 825,
    4: 1150,
    5: 700
}

# Parámetros de Pyomo modificables desde la app
model.d = Param(model.I, initialize=d, mutable=True)
model.DM = Param(model.C, initialize=DM, mutable=True)

# Demanda real de cada CT en cada hora: D_ci = DM_c * d_i
def demanda_real(model, c, i):
    return model.DM[c] * model.d[i]

model.D = Expression(model.C, model.I, rule=demanda_real)

# PARÁMETROS DE CENTRALES TÉRMICAS
# Potencia máxima de cada central térmica (MW)
NMAXT = {
    "A": 1350,
    "C": 700,
    "F": 1050
}

# Porcentaje mínimo de funcionamiento
nminT = {
    "A": 0.40,
    "C": 0.50,
    "F": 0.40
}

# Coste de funcionamiento al mínimo (€/h)
CMINT = {
    "A": 4000,
    "C": 5000,
    "F": 9000
}

# Coste por MW producido por encima del mínimo (€/MW)
CEXTT = {
    "A": 5,
    "C": 4.5,
    "F": 5
}

# Coste de puesta en marcha (€)
CPMT = {
    "A": 3000,
    "C": 2000,
    "F": 1000
}

# Parámetros de Pyomo modificables desde la app
model.NMAXT = Param(model.T, initialize=NMAXT, mutable=True)
model.nminT = Param(model.T, initialize=nminT, mutable=True)
model.CMINT = Param(model.T, initialize=CMINT, mutable=True)
model.CEXTT = Param(model.T, initialize=CEXTT, mutable=True)
model.CPMT = Param(model.T, initialize=CPMT, mutable=True)

# PARÁMETROS DE CENTRALES HIDRÁULICAS
# Potencia generada cuando la central está funcionando (MW)
NGH = {
    "B": 450,
    "E": 400
}

# Coste de funcionamiento (€/h)
CHH = {
    "B": 350,
    "E": 300
}

# Coste de puesta en marcha (€)
CPMH = {
    "B": 2000,
    "E": 2000
}

# Reducción del nivel de agua al generar (m/h)
RNAH = {
    "B": 0.30,
    "E": 0.48
}

# Nivel inicial del agua (m)
NIH = {
    "B": 10,
    "E": 10
}

# Parámetros generales del embalse
LIH = 10       # Nivel mínimo normal (m)
LSH = 20       # Nivel máximo (m)
ES = 3300      # Energía necesaria para subir 1 m (MWh/m)
MB = 33000     # Big-M para el bombeo
Delta_t = 1    # Duración de cada periodo (h)

# Parámetros de Pyomo modificables desde la app
model.NGH = Param(model.H, initialize=NGH, mutable=True)
model.CHH = Param(model.H, initialize=CHH, mutable=True)
model.CPMH = Param(model.H, initialize=CPMH, mutable=True)
model.RNAH = Param(model.H, initialize=RNAH, mutable=True)
model.NIH = Param(model.H, initialize=NIH, mutable=True)

model.LIH = Param(initialize=LIH, mutable=True)
model.LSH = Param(initialize=LSH, mutable=True)
model.ES = Param(initialize=ES, mutable=True)

model.MB = Param(initialize=MB, mutable=True)
model.Delta_t = Param(initialize=Delta_t)

# PARÁMETROS DE LA CENTRAL NUCLEAR
# Potencia máxima (MW)
NMAXN = {
    "D": 1000
}

# Porcentaje mínimo de funcionamiento
nminN = {
    "D": 0.50
}

# Coste de funcionamiento al mínimo (€/h)
CMINN = {
    "D": 4000
}

# Coste de puesta en marcha (€)
CPMN = {
    "D": 3000
}

# Parámetros de Pyomo modificables desde la app
model.NMAXN = Param(model.N, initialize=NMAXN, mutable=True)
model.nminN = Param(model.N, initialize=nminN, mutable=True)
model.CMINN = Param(model.N, initialize=CMINN, mutable=True)
model.CPMN = Param(model.N, initialize=CPMN, mutable=True)

# PARÁMETROS DE LA CURVA SOS2 DE LA NUCLEAR
# Potencia extra sobre el mínimo nuclear (MW)
PEX = {
    1: 0,
    2: 50,
    3: 125,
    4: 380,
    5: 440,
    6: 500
}

# Precio de la potencia extra (€/MW)
PREC = {
    1: 0,
    2: 2.25,
    3: 3.65,
    4: 5,
    5: 6.35,
    6: 10
}

# Parámetros de Pyomo modificables desde la app
model.PEX = Param(model.K, initialize=PEX, mutable=True)
model.PREC = Param(model.K, initialize=PREC, mutable=True)

# Coste extra total de cada punto: CEX_k = PEX_k * PREC_k
def coste_extra_punto(model, k):
    return model.PEX[k] * model.PREC[k]

model.CEX = Expression(model.K, rule=coste_extra_punto)


# PARÁMETROS DE COMPRA Y VENTA DE ELECTRICIDAD
# Precio de compra de electricidad por hora (€/MWh)
PC = {
    0: 4.6, 1: 4.4, 2: 4.3, 3: 4.2,
    4: 4.2, 5: 4.4, 6: 4.8, 7: 5.2,
    8: 5.6, 9: 5.8, 10: 5.5, 11: 5.1,
    12: 4.9, 13: 4.7, 14: 4.6, 15: 4.8,
    16: 5.2, 17: 5.8, 18: 6.5, 19: 7.2,
    20: 8.0, 21: 9.0, 22: 8.5, 23: 6.8
}

# Precio de venta de electricidad por hora (€/MWh)
PV = {
    0: 4.0, 1: 3.8, 2: 3.7, 3: 3.6,
    4: 3.6, 5: 3.8, 6: 4.2, 7: 4.6,
    8: 5.0, 9: 5.2, 10: 4.9, 11: 4.5,
    12: 4.3, 13: 4.1, 14: 4.0, 15: 4.2,
    16: 4.6, 17: 5.2, 18: 5.9, 19: 6.5,
    20: 7.3, 21: 8.2, 22: 7.7, 23: 6.1
}

# Parámetros de Pyomo
model.PC = Param(model.I, initialize=PC, mutable=True)
model.PV = Param(model.I, initialize=PV, mutable=True)

# PARÁMETROS DE LA RED
# Capacidad máxima de cada línea (MW)
CAP = {
    "A1": 500,
    "A4": 600,
    "A5": 500,
    "B1": 200,
    "B2": 500,
    "C2": 500,
    "C3": 500,
    "D2": 500,
    "D4": 500,
    "E3": 500,
    "E4": 400,
    "F3": 500,
    "F5": 400,
    "EXT1": 500, #hipótesis
    "EXT5": 500 #hipótesis
}

model.CAP = Param(model.L, initialize=CAP, mutable=True)

# PARÁMETRO DE RESERVA
PR = 0.15

model.PR = Param(initialize=PR, mutable=True)





# VARIABLES

#VARIABLES CONTINUAS
# Potencia generada por las centrales térmicas (MW)
model.PT = Var(model.T, model.I, domain=NonNegativeReals)

# Potencia generada por las centrales hidráulicas (MW)
model.PH = Var(model.H, model.I, domain=NonNegativeReals)

# Potencia generada por la central nuclear (MW)
model.PN = Var(model.N, model.I, domain=NonNegativeReals)

# Líneas de las centrales térmicas y nuclear
LINEAS_GENERACION = [
    "A1", "A4", "A5",
    "C2", "C3",
    "D2", "D4",
    "F3", "F5"
]


# Límites de los flujos de las líneas
# Referencias a CAP mutable: las cotas se actualizan al editar desde la app.
def limites_flujo(model, l, i):

    # Térmicas y nuclear:
    # solo pueden enviar energía hacia los CT
    if l in LINEAS_GENERACION:
        return (0, model.CAP[l])

    # Hidráulicas y conexiones exteriores:
    # pueden tener flujo en ambos sentidos
    return (-model.CAP[l], model.CAP[l])


# Flujo de potencia por las líneas de la red (MW)
model.F = Var(
    model.L,
    model.I,
    domain=Reals,
    bounds=limites_flujo
)

# Nivel de agua de los embalses (m)
model.NAH = Var(model.H, model.I, domain=NonNegativeReals)

# Potencia utilizada para bombear agua (MW)
model.PB = Var(model.H, model.I, domain=NonNegativeReals)

# SUBCONJUNTO DE CT CON CONEXIÓN AL EXTERIOR
# Centros de transformación conectados a redes exteriores
model.CEXT = Set(within=model.C, initialize=[1, 5])

# VARIABLES DE COMPRA Y VENTA DE ELECTRICIDAD
# Electricidad comprada al exterior (MW)
model.COMP = Var(model.CEXT, model.I, domain=NonNegativeReals)

# Electricidad vendida al exterior (MW)
model.VENT = Var(model.CEXT, model.I, domain=NonNegativeReals)

# VARIABLES DE LA CURVA SOS2 NUCLEAR
# Pesos de interpolación entre los puntos de la curva
model.lam = Var(model.K, model.I, domain=NonNegativeReals)

# Coste extra de producción nuclear (€)
model.CEXTN = Var(model.N, model.I, domain=NonNegativeReals)

# VARIABLES DE RESERVA
# Reserva disponible de las centrales térmicas (MW)
model.RT = Var(model.I, domain=NonNegativeReals)

# Reserva disponible de las centrales hidráulicas (MW)
model.RH = Var(model.I, domain=NonNegativeReals)

# Reserva disponible al detener el bombeo (MW)
model.RB = Var(model.I, domain=NonNegativeReals)





# VARIABLES BINARIAS
# Estado de las centrales térmicas: 1 si está encendida, 0 si está apagada
model.alphaT = Var(model.T, model.I, domain=Binary)

# Estado de las centrales hidráulicas: 1 si está generando, 0 si no
model.alphaH = Var(model.H, model.I, domain=Binary)

# Estado de la central nuclear: 1 si está encendida, 0 si está apagada
model.alphaN = Var(model.N, model.I, domain=Binary)

# Variables de arranque
# 1 si una central térmica arranca en esa hora
model.aT = Var(model.T, model.I, domain=Binary)

# 1 si una central hidráulica arranca en esa hora
model.aH = Var(model.H, model.I, domain=Binary)

# 1 si la central nuclear arranca en esa hora
model.aN = Var(model.N, model.I, domain=Binary)


# Bombeo hidráulico
# 1 si se habilita el modo de bombeo
model.alphaBH = Var(model.H, model.I, domain=Binary)


# Compra y venta exterior
# 1 si se permite comprar electricidad en ese CT y hora
model.betaCOMP = Var(model.CEXT, model.I, domain=Binary)

# 1 si se permite vender electricidad en ese CT y hora
model.betaVENT = Var(model.CEXT, model.I, domain=Binary)





# RESTRICCIONES

# RESTRICCIONES DE CENTRALES TÉRMICAS
# Potencia máxima de cada central térmica
def restriccion_max_termica(model, t, i):
    return model.PT[t, i] <= model.NMAXT[t] * model.alphaT[t, i]

model.max_termica = Constraint(model.T, model.I, rule=restriccion_max_termica)

# Potencia mínima de cada central térmica cuando está encendida
def restriccion_min_termica(model, t, i):
    return model.PT[t, i] >= model.nminT[t] * model.NMAXT[t] * model.alphaT[t, i]

model.min_termica = Constraint(model.T, model.I, rule=restriccion_min_termica)

# Arranque de las centrales térmicas desde la hora 1 hasta la 23
def restriccion_arranque_termica(model, t, i):
    if i == 0:
        return Constraint.Skip
    return model.aT[t, i] >= model.alphaT[t, i] - model.alphaT[t, i-1]

model.arranque_termica = Constraint(model.T, model.I, rule=restriccion_arranque_termica)

# Todas las centrales están apagadas antes de la hora 0
def restriccion_arranque_termica_hora0(model, t):
    return model.aT[t, 0] == model.alphaT[t, 0]

model.arranque_termica_hora0 = Constraint(model.T, rule=restriccion_arranque_termica_hora0)




# RESTRICCIONES DE CENTRALES HIDRÁULICAS
# Producción fija cuando la hidráulica está funcionando
def restriccion_produccion_hidraulica(model, h, i):
    return model.PH[h, i] == model.NGH[h] * model.alphaH[h, i]

model.produccion_hidraulica = Constraint(model.H, model.I, rule=restriccion_produccion_hidraulica)

# Arranque de las centrales hidráulicas desde la hora 1 hasta la 23
def restriccion_arranque_hidraulica(model, h, i):
    if i == 0:
        return Constraint.Skip
    return model.aH[h, i] >= model.alphaH[h, i] - model.alphaH[h, i-1]

model.arranque_hidraulica = Constraint(model.H, model.I, rule=restriccion_arranque_hidraulica)

# Todas las hidráulicas están apagadas antes de la hora 0
def restriccion_arranque_hidraulica_hora0(model, h):
    return model.aH[h, 0] == model.alphaH[h, 0]

model.arranque_hidraulica_hora0 = Constraint(model.H, rule=restriccion_arranque_hidraulica_hora0)

# Una hidráulica no puede generar y bombear al mismo tiempo
def restriccion_generar_bombear(model, h, i):
    return model.alphaH[h, i] + model.alphaBH[h, i] <= 1

model.generar_bombear = Constraint(model.H, model.I,rule=restriccion_generar_bombear)

# Nivel mínimo del embalse
def restriccion_nivel_minimo(model, h, i):
    return model.NAH[h, i] >= model.LIH

model.nivel_minimo = Constraint(model.H, model.I,rule=restriccion_nivel_minimo)

# Nivel máximo del embalse
def restriccion_nivel_maximo(model, h, i):
    return model.NAH[h, i] <= model.LSH

model.nivel_maximo = Constraint(model.H, model.I,rule=restriccion_nivel_maximo)

# Balance de agua en la hora 0
def restriccion_balance_agua_hora0(model, h):
    return model.NAH[h, 0] == (model.NIH[h]+ model.PB[h, 0] * model.Delta_t / model.ES
                            - model.RNAH[h] * model.alphaH[h, 0])

model.balance_agua_hora0 = Constraint(model.H,rule=restriccion_balance_agua_hora0)

# Balance de agua desde la hora 1 hasta la 23
def restriccion_balance_agua(model, h, i):
    if i == 0:
        return Constraint.Skip

    return model.NAH[h, i] == (model.NAH[h, i-1]+ model.PB[h, i] * model.Delta_t / model.ES
                            - model.RNAH[h] * model.alphaH[h, i])

model.balance_agua = Constraint(model.H, model.I,rule=restriccion_balance_agua)

# El bombeo solo puede existir si está habilitado
def restriccion_bombeo(model, h, i):
    return model.PB[h, i] <= model.MB * model.alphaBH[h, i]

model.bombeo = Constraint(model.H, model.I,rule=restriccion_bombeo)




# RESTRICCIONES DE LA CENTRAL NUCLEAR
# Potencia máxima de la central nuclear
def restriccion_max_nuclear(model, n, i):
    return model.PN[n, i] <= model.NMAXN[n] * model.alphaN[n, i]

model.max_nuclear = Constraint(model.N, model.I, rule=restriccion_max_nuclear)

# Potencia mínima de la central nuclear cuando está encendida
def restriccion_min_nuclear(model, n, i):
    return model.PN[n, i] >= (model.nminN[n] * model.NMAXN[n] * model.alphaN[n, i])

model.min_nuclear = Constraint(model.N, model.I,rule=restriccion_min_nuclear)

# Arranque de la nuclear desde la hora 1 hasta la 23
def restriccion_arranque_nuclear(model, n, i):
    if i == 0:
        return Constraint.Skip
    return model.aN[n, i] >= model.alphaN[n, i] - model.alphaN[n, i-1]

model.arranque_nuclear = Constraint(model.N, model.I,rule=restriccion_arranque_nuclear)

# La nuclear está apagada antes de la hora 0
def restriccion_arranque_nuclear_hora0(model, n):
    return model.aN[n, 0] == model.alphaN[n, 0]

model.arranque_nuclear_hora0 = Constraint(model.N,rule=restriccion_arranque_nuclear_hora0)




# RESTRICCIONES DE LA CURVA SOS2 NUCLEAR
# La suma de los pesos lambda vale 1 si la nuclear está encendida y 0 si está apagada
def restriccion_suma_lambda(model, n, i):
    return sum(model.lam[k, i] for k in model.K) == model.alphaN[n, i]

model.suma_lambda = Constraint(model.N, model.I,rule=restriccion_suma_lambda)

# Relación entre la potencia nuclear extra y los puntos de la curva
def restriccion_potencia_extra_nuclear(model, n, i):
    return (
        model.PN[n, i]- model.nminN[n] * model.NMAXN[n] * model.alphaN[n, i] ==
        sum(model.PEX[k] * model.lam[k, i] for k in model.K)
    )

model.potencia_extra_nuclear = Constraint(model.N, model.I,rule=restriccion_potencia_extra_nuclear)

# Coste extra de producción nuclear
def restriccion_coste_extra_nuclear(model, n, i):
    return model.CEXTN[n, i] == sum(model.CEX[k] * model.lam[k, i] for k in model.K)

model.coste_extra_nuclear = Constraint(model.N, model.I,rule=restriccion_coste_extra_nuclear)

# CONDICIÓN SOS2 DE LA CURVA NUCLEAR
# Como máximo dos lambdas pueden ser positivas y deben ser consecutivas
def sos2_nuclear_rule(model, i):
    return [model.lam[k, i] for k in model.K]

model.sos2_nuclear = SOSConstraint(model.I,rule=sos2_nuclear_rule,sos=2)




# RESTRICCIONES DE LA RED

# CENTRAL HIDRÁULICA B

def restriccion_sentido_B1_min(model, i):
    return model.F["B1", i] >= -model.CAP["B1"] * model.alphaBH["B", i]

model.sentido_B1_min = Constraint(model.I, rule=restriccion_sentido_B1_min)

def restriccion_sentido_B1_max(model, i):
    return model.F["B1", i] <= model.CAP["B1"] * model.alphaH["B", i]

model.sentido_B1_max = Constraint(model.I, rule=restriccion_sentido_B1_max)


def restriccion_sentido_B2_min(model, i):
    return model.F["B2", i] >= -model.CAP["B2"] * model.alphaBH["B", i]

model.sentido_B2_min = Constraint(model.I, rule=restriccion_sentido_B2_min)

def restriccion_sentido_B2_max(model, i):
    return model.F["B2", i] <= model.CAP["B2"] * model.alphaH["B", i]

model.sentido_B2_max = Constraint(model.I, rule=restriccion_sentido_B2_max)


# CENTRAL HIDRÁULICA E

def restriccion_sentido_E3_min(model, i):
    return model.F["E3", i] >= -model.CAP["E3"] * model.alphaBH["E", i]

model.sentido_E3_min = Constraint(model.I, rule=restriccion_sentido_E3_min)

def restriccion_sentido_E3_max(model, i):
    return model.F["E3", i] <= model.CAP["E3"] * model.alphaH["E", i]

model.sentido_E3_max = Constraint(model.I, rule=restriccion_sentido_E3_max)


def restriccion_sentido_E4_min(model, i):
    return model.F["E4", i] >= -model.CAP["E4"] * model.alphaBH["E", i]

model.sentido_E4_min = Constraint(model.I, rule=restriccion_sentido_E4_min)

def restriccion_sentido_E4_max(model, i):
    return model.F["E4", i] <= model.CAP["E4"] * model.alphaH["E", i]

model.sentido_E4_max = Constraint(model.I, rule=restriccion_sentido_E4_max)


# BALANCES DE LAS CENTRALES
# Central térmica A
def balance_A(model, i):
    return model.PT["A", i] == (model.F["A1", i]+ model.F["A4", i]+ model.F["A5", i])

model.balance_A = Constraint(model.I, rule=balance_A)

# Central hidráulica B
def balance_B(model, i):
    return model.PH["B", i] - model.PB["B", i] == (model.F["B1", i]+ model.F["B2", i])

model.balance_B = Constraint(model.I, rule=balance_B)

# Central térmica C
def balance_C(model, i):
    return model.PT["C", i] == (model.F["C2", i]+ model.F["C3", i])

model.balance_C = Constraint(model.I, rule=balance_C)

# Central nuclear D
def balance_D(model, i):
    return model.PN["D", i] == ( model.F["D2", i]+ model.F["D4", i])

model.balance_D = Constraint(model.I, rule=balance_D)

# Central hidráulica E
def balance_E(model, i):
    return model.PH["E", i] - model.PB["E", i] == (model.F["E3", i]+ model.F["E4", i])

model.balance_E = Constraint(model.I, rule=balance_E)

# Central térmica F
def balance_F(model, i):
    return model.PT["F", i] == (model.F["F3", i]+ model.F["F5", i])

model.balance_F = Constraint(model.I, rule=balance_F)


# BALANCES DE LOS CENTROS DE TRANSFORMACIÓN
# CT1
def balance_CT1(model, i):
    return (model.F["A1", i]+ model.F["B1", i]+ model.F["EXT1", i]== model.D[1, i])

model.balance_CT1 = Constraint(model.I, rule=balance_CT1)

# CT2
def balance_CT2(model, i):
    return (model.F["B2", i]+ model.F["C2", i]+ model.F["D2", i]== model.D[2, i])

model.balance_CT2 = Constraint(model.I, rule=balance_CT2)

# CT3
def balance_CT3(model, i):
    return ( model.F["C3", i]+ model.F["E3", i]+ model.F["F3", i]== model.D[3, i])

model.balance_CT3 = Constraint(model.I, rule=balance_CT3)

# CT4
def balance_CT4(model, i):
    return (model.F["A4", i]+ model.F["D4", i]+ model.F["E4", i]== model.D[4, i])

model.balance_CT4 = Constraint(model.I, rule=balance_CT4)

# CT5
def balance_CT5(model, i):
    return (model.F["A5", i]+ model.F["F5", i]+ model.F["EXT5", i]== model.D[5, i])

model.balance_CT5 = Constraint(model.I, rule=balance_CT5)




# COMPRA Y VENTA DE ENERGÍA AL EXTERIOR
# Límite de compra en CT1
def restriccion_compra_CT1(model, i):
    return model.COMP[1, i] <= (model.CAP["EXT1"] * model.betaCOMP[1, i])

model.compra_CT1 = Constraint(model.I,rule=restriccion_compra_CT1)

# Límite de compra en CT5
def restriccion_compra_CT5(model, i):
    return model.COMP[5, i] <= (model.CAP["EXT5"] * model.betaCOMP[5, i])

model.compra_CT5 = Constraint(model.I,rule=restriccion_compra_CT5)

# Límite de venta en CT1
def restriccion_venta_CT1(model, i):
    return model.VENT[1, i] <= (model.CAP["EXT1"] * model.betaVENT[1, i])

model.venta_CT1 = Constraint(model.I,rule=restriccion_venta_CT1)

# Límite de venta en CT5
def restriccion_venta_CT5(model, i):
    return model.VENT[5, i] <= (model.CAP["EXT5"] * model.betaVENT[5, i])

model.venta_CT5 = Constraint(model.I,rule=restriccion_venta_CT5)


# No se puede comprar y vender simultáneamente
def restriccion_compra_venta_simultanea(model, c, i):
    return (model.betaCOMP[c, i]+ model.betaVENT[c, i]<= 1)

model.compra_venta_simultanea = Constraint(model.CEXT,model.I,rule=restriccion_compra_venta_simultanea)

# Relación entre compra, venta y flujo exterior en CT1
def restriccion_flujo_exterior_CT1(model, i):
    return (model.F["EXT1", i]== model.COMP[1, i] - model.VENT[1, i])

model.flujo_exterior_CT1 = Constraint(model.I,rule=restriccion_flujo_exterior_CT1)

# Relación entre compra, venta y flujo exterior en CT5
def restriccion_flujo_exterior_CT5(model, i):
    return (model.F["EXT5", i]== model.COMP[5, i] - model.VENT[5, i])

model.flujo_exterior_CT5 = Constraint(model.I,rule=restriccion_flujo_exterior_CT5)




# RESERVA DEL SISTEMA
# Reserva disponible en las centrales térmicas
def restriccion_reserva_termica(model, i):
    return model.RT[i] == sum(model.NMAXT[t] * model.alphaT[t, i] - model.PT[t, i]for t in model.T)

model.reserva_termica = Constraint(model.I,rule=restriccion_reserva_termica)

# Reserva disponible en las centrales hidráulicas
def restriccion_reserva_hidraulica(model, i):
    return model.RH[i] == sum(model.NGH[h] * (1 - model.alphaH[h, i])for h in model.H)

model.reserva_hidraulica = Constraint(model.I,rule=restriccion_reserva_hidraulica)

# Reserva obtenida al detener el bombeo
def restriccion_reserva_bombeo(model, i):
    return model.RB[i] == sum(model.PB[h, i]for h in model.H)

model.reserva_bombeo = Constraint(model.I,rule=restriccion_reserva_bombeo)

# La reserva total debe cubrir al menos el 15 % de la demanda
def restriccion_reserva_total(model, i):
    return (model.RT[i]+ model.RH[i]+ model.RB[i]>= model.PR * sum(model.D[c, i] for c in model.C))

model.reserva_total = Constraint(model.I,rule=restriccion_reserva_total)





# FUNCIÓN OBJETIVO

def funcion_objetivo(model):

    # Costes de las centrales térmicas
    coste_termicas = sum(model.CMINT[t] * model.alphaT[t, i]+ model.CEXTT[t] * (model.PT[t, i]
                - model.nminT[t] * model.NMAXT[t] * model.alphaT[t, i]) + model.CPMT[t] * model.aT[t, i] 
        for t in model.T 
        for i in model.I)

    # Costes de las centrales hidráulicas
    coste_hidraulicas = sum(model.CHH[h] * model.alphaH[h, i] + model.CPMH[h] * model.aH[h, i]
        for h in model.H
        for i in model.I)

    # Costes de la central nuclear
    coste_nuclear = sum(model.CMINN[n] * model.alphaN[n, i]+ model.CEXTN[n, i]+ model.CPMN[n] * model.aN[n, i]
        for n in model.N
        for i in model.I
    )

    # Compra y venta de energía al exterior
    coste_mercado = sum((model.PC[i] * model.COMP[c, i] - model.PV[i] * model.VENT[c, i]) * model.Delta_t
        for c in model.CEXT
        for i in model.I
    )

    return (coste_termicas + coste_hidraulicas + coste_nuclear + coste_mercado
    )

model.objetivo = Objective(rule=funcion_objetivo,sense=minimize)


# RESOLUCIÓN DEL MODELO

def resolver_modelo():

    solver = SolverFactory("gurobi_direct")

    resultado = solver.solve(
        model,
        tee=False
    )

    return resultado

# OBTENER RESULTADOS PARA LA APP

def obtener_resultados():

    resultados = {
    "coste_total": round(value(model.objetivo), 2),
    "horas": [],
    "flujos": []
}

    for i in model.I:

        resultados["horas"].append({
            "hora": i,

            # Demanda total
            "demanda": sum(value(model.D[c, i]) for c in model.C),

            # Producción de las centrales
            "A": value(model.PT["A", i]),
            "B": value(model.PH["B", i]),
            "C": value(model.PT["C", i]),
            "D": value(model.PN["D", i]),
            "E": value(model.PH["E", i]),
            "F": value(model.PT["F", i]),

            # Compra y venta exterior
            "compra": sum(value(model.COMP[c, i]) for c in model.CEXT),
            "venta": sum(value(model.VENT[c, i]) for c in model.CEXT),

            # Bombeo
            "bombeo_B": value(model.PB["B", i]),
            "bombeo_E": value(model.PB["E", i]),

            # Nivel de los embalses
            "nivel_B": value(model.NAH["B", i]),
            "nivel_E": value(model.NAH["E", i]),

            # Reserva
            "reserva_termica": value(model.RT[i]),
            "reserva_hidraulica": value(model.RH[i]),
            "reserva_bombeo": value(model.RB[i]),
            "reserva_total": (
                value(model.RT[i])
                + value(model.RH[i])
                + value(model.RB[i])
            )
        })

    # Flujos de las líneas por hora
    for i in model.I:

        flujo_hora = {
            "hora": i
        }

        for l in model.L:
            flujo_hora[l] = value(model.F[l, i])

        resultados["flujos"].append(flujo_hora)
        
    return resultados

# Ejecutar el modelo si abrimos directamente este archivo
if __name__ == "__main__":

    resultado = resolver_modelo()

    print("\nRESULTADO DEL MODELO")
    print("Estado:", resultado.solver.status)
    print("Terminación:", resultado.solver.termination_condition)

    if resultado.solver.termination_condition == TerminationCondition.optimal:
        print("Coste total:", round(value(model.objetivo), 2), "€")
    else:
        print("El modelo no tiene una solución factible.")

